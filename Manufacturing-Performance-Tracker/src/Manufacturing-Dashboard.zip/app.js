// Data structures and state management
const state = {
  selectedPlant: 'PA',
  selectedMachine: null,
  timeRange: '24h',
  machines: {},
  alerts: [],
  plantData: {}
};

const plants = [
  { name: 'Plant A - Mumbai', id: 'PA', location: 'Mumbai, India' },
  { name: 'Plant B - Bangalore', id: 'PB', location: 'Bangalore, India' },
  { name: 'Plant C - Chennai', id: 'PC', location: 'Chennai, India' }
];

const alertTypes = [
  'Bearing Wear Detected',
  'Temperature Spike',
  'Vibration Anomaly',
  'Energy Consumption High',
  'Cycle Time Exceeds Threshold',
  'Scrap Rate Abnormal',
  'Scheduled Maintenance Due'
];

const alertSeverities = ['CRITICAL', 'WARNING', 'INFO'];

// Generate initial machine data
function initializeMachines() {
  plants.forEach(plant => {
    state.machines[plant.id] = [];
    for (let i = 1; i <= 12; i++) {
      const machineId = `M${i.toString().padStart(2, '0')}`;
      state.machines[plant.id].push({
        id: machineId,
        plantId: plant.id,
        status: getRandomStatus(),
        uptime: randomInRange(85, 98),
        efficiency: randomInRange(60, 95),
        oee: randomInRange(65, 90),
        availability: randomInRange(75, 95),
        performance: randomInRange(75, 95),
        quality: randomInRange(90, 99),
        vibration: randomInRange(0, 10),
        temperature: randomInRange(20, 80),
        energy: randomInRange(10, 50),
        cycleTime: randomInRange(30, 120),
        defectRate: randomInRange(0.1, 5),
        throughput: randomInRange(20, 100),
        vibrationHistory: generateTimeSeriesData(50, 0, 10),
        temperatureHistory: generateTimeSeriesData(50, 20, 80),
        energyHistory: generateTimeSeriesData(50, 10, 50)
      });
    }
  });
}

function getRandomStatus() {
  const rand = Math.random();
  if (rand < 0.6) return 'running';
  if (rand < 0.8) return 'idle';
  if (rand < 0.95) return 'maintenance';
  return 'fault';
}

function randomInRange(min, max) {
  return Math.random() * (max - min) + min;
}

function generateTimeSeriesData(count, min, max) {
  const data = [];
  let lastValue = (min + max) / 2;
  for (let i = 0; i < count; i++) {
    const change = (Math.random() - 0.5) * (max - min) * 0.1;
    lastValue = Math.max(min, Math.min(max, lastValue + change));
    data.push(lastValue);
  }
  return data;
}

// Generate alerts
function generateAlerts() {
  state.alerts = [];
  const currentPlantMachines = state.machines[state.selectedPlant];
  const alertCount = Math.floor(Math.random() * 3) + 3; // 3-5 alerts
  
  for (let i = 0; i < alertCount; i++) {
    const machine = currentPlantMachines[Math.floor(Math.random() * currentPlantMachines.length)];
    const type = alertTypes[Math.floor(Math.random() * alertTypes.length)];
    const severity = alertSeverities[Math.floor(Math.random() * alertSeverities.length)];
    const hoursAgo = Math.floor(Math.random() * 24);
    const predictedDays = Math.floor(Math.random() * 30) + 1;
    
    state.alerts.push({
      id: `alert-${i}`,
      machineId: machine.id,
      type,
      severity,
      timestamp: new Date(Date.now() - hoursAgo * 3600000),
      predictedFailure: predictedDays,
      rootCause: generateRootCause(type)
    });
  }
  
  state.alerts.sort((a, b) => {
    const severityOrder = { CRITICAL: 0, WARNING: 1, INFO: 2 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });
}

function generateRootCause(alertType) {
  const causes = {
    'Bearing Wear Detected': 'ML clustering detected abnormal vibration pattern. Correlation with temperature increase suggests bearing degradation.',
    'Temperature Spike': 'Anomaly detection identified sudden 15°C increase. Likely caused by cooling system inefficiency.',
    'Vibration Anomaly': 'FFT analysis shows frequency spikes at 2.5Hz and 5.0Hz, indicating unbalanced rotor.',
    'Energy Consumption High': 'Energy consumption 25% above baseline. Correlated with increased friction in drive system.',
    'Cycle Time Exceeds Threshold': 'Performance degradation detected. Root cause: worn cutting tools reducing feed rate.',
    'Scrap Rate Abnormal': 'Quality metrics show dimensional deviation. Calibration drift detected in positioning system.',
    'Scheduled Maintenance Due': 'Preventive maintenance window approaching based on operating hours threshold.'
  };
  return causes[alertType] || 'Analysis in progress...';
}

// Calculate plant-level metrics
function calculatePlantMetrics() {
  const machines = state.machines[state.selectedPlant];
  const oee = machines.reduce((sum, m) => sum + m.oee, 0) / machines.length;
  const throughput = machines.reduce((sum, m) => sum + m.throughput, 0);
  const defectRate = machines.reduce((sum, m) => sum + m.defectRate, 0) / machines.length;
  const energy = machines.reduce((sum, m) => sum + m.energy, 0);
  
  return { oee, throughput, defectRate, energy };
}

// Update time display
function updateTimeDisplay() {
  const now = new Date();
  const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
  };
  document.getElementById('timeDisplay').textContent = now.toLocaleString('en-IN', options) + ' IST';
}

// Update system status
function updateSystemStatus() {
  const criticalAlerts = state.alerts.filter(a => a.severity === 'CRITICAL').length;
  const warningAlerts = state.alerts.filter(a => a.severity === 'WARNING').length;
  
  const statusDot = document.querySelector('.status-dot');
  const statusText = document.querySelector('.status-text');
  
  if (criticalAlerts > 0) {
    statusDot.className = 'status-dot critical';
    statusText.textContent = 'Critical Issues';
  } else if (warningAlerts > 0) {
    statusDot.className = 'status-dot warning';
    statusText.textContent = 'Warnings Active';
  } else {
    statusDot.className = 'status-dot';
    statusText.textContent = 'Operational';
  }
}

// Render plant view
function renderPlantView() {
  const metrics = calculatePlantMetrics();
  
  // Update OEE gauge
  const oeeValue = document.getElementById('oeeValue');
  const oeeGaugeFill = document.getElementById('oeeGaugeFill');
  oeeValue.textContent = metrics.oee.toFixed(1) + '%';
  const dashArray = (metrics.oee / 100) * 251.2;
  oeeGaugeFill.style.strokeDasharray = `${dashArray} 251.2`;
  
  // Update throughput
  animateValue('throughputValue', metrics.throughput, 0);
  
  // Update defect rate
  const defectRateValue = document.getElementById('defectRateValue');
  defectRateValue.textContent = metrics.defectRate.toFixed(2) + '%';
  
  // Update energy
  animateValue('energyValue', metrics.energy, 1);
  
  // Render machine grid
  renderMachineGrid();
  
  // Render charts
  renderPlantCharts();
}

function animateValue(elementId, targetValue, decimals = 0) {
  const element = document.getElementById(elementId);
  const currentValue = parseFloat(element.textContent) || 0;
  const increment = (targetValue - currentValue) / 20;
  let current = currentValue;
  
  const timer = setInterval(() => {
    current += increment;
    if ((increment > 0 && current >= targetValue) || (increment < 0 && current <= targetValue)) {
      current = targetValue;
      clearInterval(timer);
    }
    element.textContent = decimals > 0 ? current.toFixed(decimals) : Math.round(current);
  }, 50);
}

function renderMachineGrid() {
  const grid = document.getElementById('machineGrid');
  const machines = state.machines[state.selectedPlant];
  
  grid.innerHTML = machines.map(machine => `
    <div class="machine-card ${machine.status}" data-machine="${machine.id}" onclick="showMachineDetail('${machine.id}')">
      <div class="machine-card-header">
        <div class="machine-name">${machine.id}</div>
        <div class="machine-status ${machine.status}">${machine.status}</div>
      </div>
      <div class="machine-metrics">
        <div class="metric">
          <span class="metric-label">Uptime</span>
          <span class="metric-value">${machine.uptime.toFixed(1)}%</span>
        </div>
        <div class="metric">
          <span class="metric-label">Efficiency</span>
          <span class="metric-value">${machine.efficiency.toFixed(1)}%</span>
        </div>
      </div>
      <div class="machine-chart">
        <canvas id="miniChart-${machine.id}"></canvas>
      </div>
    </div>
  `).join('');
  
  // Render mini charts
  machines.forEach(machine => {
    renderMiniChart(machine.id);
  });
}

function renderMiniChart(machineId) {
  const canvas = document.getElementById(`miniChart-${machineId}`);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  const machine = state.machines[state.selectedPlant].find(m => m.id === machineId);
  
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: Array(20).fill(''),
      datasets: [{
        data: machine.vibrationHistory.slice(-20),
        borderColor: '#1FB8CD',
        borderWidth: 2,
        fill: false,
        tension: 0.4,
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { display: false }
      }
    }
  });
}

// Charts
let plantCharts = {};

function renderPlantCharts() {
  // Clear existing charts
  Object.values(plantCharts).forEach(chart => chart.destroy());
  plantCharts = {};
  
  // OEE Trend Chart
  const oeeTrendCtx = document.getElementById('oeeTrendChart');
  if (oeeTrendCtx) {
    plantCharts.oeeTrend = new Chart(oeeTrendCtx, {
      type: 'line',
      data: {
        labels: generateTimeLabels(24),
        datasets: [{
          label: 'OEE %',
          data: generateTimeSeriesData(24, 65, 90),
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          fill: true,
          tension: 0.4
        }, {
          label: 'Target',
          data: Array(24).fill(85),
          borderColor: '#f59e0b',
          borderDash: [5, 5],
          fill: false
        }]
      },
      options: getChartOptions('OEE %')
    });
  }
  
  // Throughput Chart
  const throughputCtx = document.getElementById('throughputChart');
  if (throughputCtx) {
    plantCharts.throughput = new Chart(throughputCtx, {
      type: 'bar',
      data: {
        labels: generateTimeLabels(24),
        datasets: [{
          label: 'Actual',
          data: generateTimeSeriesData(24, 400, 800),
          backgroundColor: '#1FB8CD'
        }, {
          label: 'Target',
          data: Array(24).fill(800),
          type: 'line',
          borderColor: '#f59e0b',
          borderDash: [5, 5],
          fill: false
        }]
      },
      options: getChartOptions('Units')
    });
  }
  
  // Downtime Distribution
  const downtimeCtx = document.getElementById('downtimeChart');
  if (downtimeCtx) {
    const machines = state.machines[state.selectedPlant];
    const downtimeMachines = machines.filter(m => m.status !== 'running').slice(0, 5);
    
    plantCharts.downtime = new Chart(downtimeCtx, {
      type: 'doughnut',
      data: {
        labels: downtimeMachines.map(m => m.id),
        datasets: [{
          data: downtimeMachines.map(() => Math.random() * 100),
          backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F', '#DB4545']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: { position: 'right', labels: { color: '#e5e7eb' } }
        }
      }
    });
  }
  
  // Energy Chart
  const energyCtx = document.getElementById('energyChart');
  if (energyCtx) {
    plantCharts.energy = new Chart(energyCtx, {
      type: 'line',
      data: {
        labels: generateTimeLabels(24),
        datasets: [{
          label: 'Energy (kW)',
          data: generateTimeSeriesData(24, 200, 500),
          borderColor: '#f59e0b',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          fill: true,
          tension: 0.4
        }]
      },
      options: getChartOptions('kW')
    });
  }
}

function generateTimeLabels(count) {
  const labels = [];
  for (let i = count - 1; i >= 0; i--) {
    labels.push(`${i}h ago`);
  }
  return labels.reverse();
}

function getChartOptions(yAxisLabel) {
  return {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: { labels: { color: '#e5e7eb' } }
    },
    scales: {
      x: { 
        grid: { color: 'rgba(255, 255, 255, 0.1)' },
        ticks: { color: '#9ca3af' }
      },
      y: { 
        grid: { color: 'rgba(255, 255, 255, 0.1)' },
        ticks: { color: '#9ca3af' },
        title: { display: true, text: yAxisLabel, color: '#9ca3af' }
      }
    }
  };
}

// Render alerts
function renderAlerts() {
  const alertsList = document.getElementById('alertsList');
  const alertCount = document.getElementById('alertCount');
  
  alertCount.textContent = state.alerts.length;
  
  alertsList.innerHTML = state.alerts.map(alert => {
    const timeAgo = getTimeAgo(alert.timestamp);
    return `
      <div class="alert-item ${alert.severity.toLowerCase()}" onclick="handleAlertClick('${alert.id}')">
        <div class="alert-severity ${alert.severity.toLowerCase()}">${alert.severity}</div>
        <div class="alert-title">${alert.type}</div>
        <div class="alert-machine">Machine: ${alert.machineId}</div>
        <div class="alert-time">${timeAgo}</div>
        ${alert.severity === 'CRITICAL' ? `<div class="alert-prediction">⚠️ Predicted failure in ${alert.predictedFailure} days</div>` : ''}
      </div>
    `;
  }).join('');
}

function getTimeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

function handleAlertClick(alertId) {
  const alert = state.alerts.find(a => a.id === alertId);
  if (alert) {
    showMachineDetail(alert.machineId, true);
  }
}

// Machine detail view
let machineCharts = {};

function showMachineDetail(machineId, showRootCause = false) {
  state.selectedMachine = machineId;
  const machine = state.machines[state.selectedPlant].find(m => m.id === machineId);
  
  document.getElementById('plantView').classList.add('hidden');
  document.getElementById('machineView').classList.remove('hidden');
  
  // Render machine header
  const header = document.getElementById('machineHeader');
  const alert = state.alerts.find(a => a.machineId === machineId && a.severity === 'CRITICAL');
  
  header.innerHTML = `
    <div class="machine-header-left">
      <h1>Machine ${machineId}</h1>
      <div class="machine-header-status">
        <div class="machine-status ${machine.status}">${machine.status}</div>
        <span style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">Plant: ${state.selectedPlant}</span>
      </div>
    </div>
    <div class="machine-header-right">
      ${alert ? `<div class="prediction-badge">⚠️ Predicted Failure: ${alert.predictedFailure} days</div>` : ''}
    </div>
  `;
  
  // Update KPIs
  document.getElementById('machineOeeValue').textContent = machine.oee.toFixed(1) + '%';
  document.getElementById('machineUptimeValue').textContent = machine.uptime.toFixed(1) + '%';
  document.getElementById('machineCycleTime').textContent = machine.cycleTime.toFixed(0) + 's';
  document.getElementById('machineDefectCount').textContent = Math.floor(machine.defectRate * 10);
  
  // OEE Breakdown
  const oeeBreakdown = document.getElementById('oeeBreakdown');
  oeeBreakdown.innerHTML = `
    <div class="oee-component">
      <span class="oee-component-label">Availability</span>
      <span class="oee-component-value">${machine.availability.toFixed(1)}%</span>
    </div>
    <div class="oee-component">
      <span class="oee-component-label">Performance</span>
      <span class="oee-component-value">${machine.performance.toFixed(1)}%</span>
    </div>
    <div class="oee-component">
      <span class="oee-component-label">Quality</span>
      <span class="oee-component-value">${machine.quality.toFixed(1)}%</span>
    </div>
  `;
  
  // Update sensor values
  document.getElementById('vibrationValue').textContent = machine.vibration.toFixed(2) + ' Hz';
  document.getElementById('temperatureValue').textContent = machine.temperature.toFixed(1) + '°C';
  document.getElementById('energySensorValue').textContent = machine.energy.toFixed(1) + ' kW';
  
  // Render sensor charts
  renderSensorCharts(machine);
  
  // Show/hide root cause section
  if (showRootCause) {
    renderRootCauseAnalysis(machineId);
    document.getElementById('rootCauseSection').scrollIntoView({ behavior: 'smooth' });
  }
  
  // Render maintenance timeline
  renderMaintenanceTimeline(machineId);
}

function renderSensorCharts(machine) {
  Object.values(machineCharts).forEach(chart => chart.destroy());
  machineCharts = {};
  
  // Vibration Chart
  const vibrationCtx = document.getElementById('vibrationChart');
  machineCharts.vibration = new Chart(vibrationCtx, {
    type: 'line',
    data: {
      labels: Array(50).fill(''),
      datasets: [{
        label: 'Vibration (Hz)',
        data: machine.vibrationHistory,
        borderColor: '#1FB8CD',
        backgroundColor: 'rgba(31, 184, 205, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 0
      }, {
        label: 'Normal Threshold',
        data: Array(50).fill(5),
        borderColor: '#f59e0b',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0
      }]
    },
    options: getSensorChartOptions()
  });
  
  // Temperature Chart
  const temperatureCtx = document.getElementById('temperatureChart');
  machineCharts.temperature = new Chart(temperatureCtx, {
    type: 'line',
    data: {
      labels: Array(50).fill(''),
      datasets: [{
        label: 'Temperature (°C)',
        data: machine.temperatureHistory,
        borderColor: '#ff5459',
        backgroundColor: 'rgba(255, 84, 89, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 0
      }, {
        label: 'Normal Threshold',
        data: Array(50).fill(60),
        borderColor: '#f59e0b',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0
      }]
    },
    options: getSensorChartOptions()
  });
  
  // Energy Chart
  const energyCtx = document.getElementById('energySensorChart');
  machineCharts.energy = new Chart(energyCtx, {
    type: 'line',
    data: {
      labels: Array(50).fill(''),
      datasets: [{
        label: 'Energy (kW)',
        data: machine.energyHistory,
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        fill: true,
        tension: 0.4,
        pointRadius: 0
      }]
    },
    options: getSensorChartOptions()
  });
}

function getSensorChartOptions() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: { display: false },
      y: { 
        grid: { color: 'rgba(255, 255, 255, 0.1)' },
        ticks: { color: '#9ca3af' }
      }
    }
  };
}

function renderRootCauseAnalysis(machineId) {
  const alert = state.alerts.find(a => a.machineId === machineId);
  if (!alert) return;
  
  // Anomaly Heatmap
  const heatmap = document.getElementById('anomalyHeatmap');
  const heatmapData = Array(64).fill(0).map(() => Math.random());
  heatmap.innerHTML = '<div class="heatmap-grid">' + 
    heatmapData.map(value => {
      const intensity = Math.floor(value * 255);
      const color = value > 0.7 ? '#ff5459' : value > 0.4 ? '#f59e0b' : '#1FB8CD';
      return `<div class="heatmap-cell" style="background-color: ${color}; opacity: ${value}" title="${value.toFixed(2)}"></div>`;
    }).join('') + 
    '</div>';
  
  // Correlation Analysis
  const correlations = document.getElementById('correlationData');
  correlations.innerHTML = `
    <div class="correlation-item">
      <span class="correlation-label">Vibration ↔ Temperature</span>
      <span class="correlation-value">0.78</span>
    </div>
    <div class="correlation-item">
      <span class="correlation-label">Energy ↔ Throughput</span>
      <span class="correlation-value">0.92</span>
    </div>
    <div class="correlation-item">
      <span class="correlation-label">Cycle Time ↔ Quality</span>
      <span class="correlation-value">-0.65</span>
    </div>
  `;
  
  // Recommendations
  const recommendations = document.getElementById('recommendations');
  recommendations.innerHTML = `
    <div class="recommendation-item">🔧 Schedule bearing replacement within 5 days</div>
    <div class="recommendation-item">📊 Reduce feed rate by 10% to minimize vibration</div>
    <div class="recommendation-item">⚙️ Perform alignment check on drive shaft</div>
    <div class="recommendation-item">🔍 Monitor temperature trend closely for next 48 hours</div>
  `;
}

function renderMaintenanceTimeline(machineId) {
  const timeline = document.getElementById('maintenanceTimeline');
  const events = [
    { date: '2025-11-20', title: 'Scheduled Inspection', description: 'Routine maintenance completed. All systems nominal.' },
    { date: '2025-11-10', title: 'Bearing Replacement', description: 'Front bearing replaced due to wear. Performance improved by 12%.' },
    { date: '2025-10-28', title: 'Calibration', description: 'Sensor calibration performed. Accuracy restored to specification.' },
    { date: '2025-10-15', title: 'Preventive Maintenance', description: 'Oil change and filter replacement. Energy efficiency improved.' }
  ];
  
  timeline.innerHTML = events.map(event => `
    <div class="timeline-item">
      <div class="timeline-date">${event.date}</div>
      <div class="timeline-title">${event.title}</div>
      <div class="timeline-description">${event.description}</div>
    </div>
  `).join('');
}

// Event handlers
function handlePlantChange(event) {
  state.selectedPlant = event.target.value;
  generateAlerts();
  renderPlantView();
  renderAlerts();
  updateSystemStatus();
}

function handleTimeRangeChange(event) {
  document.querySelectorAll('.range-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  state.timeRange = event.target.dataset.range;
  renderPlantCharts();
}

function handleRefresh() {
  const btn = document.getElementById('refreshBtn');
  btn.classList.add('spinning');
  
  // Update all machine data
  Object.keys(state.machines).forEach(plantId => {
    state.machines[plantId].forEach(machine => {
      machine.vibration = randomInRange(0, 10);
      machine.temperature = randomInRange(20, 80);
      machine.energy = randomInRange(10, 50);
      machine.vibrationHistory.shift();
      machine.vibrationHistory.push(machine.vibration);
      machine.temperatureHistory.shift();
      machine.temperatureHistory.push(machine.temperature);
      machine.energyHistory.shift();
      machine.energyHistory.push(machine.energy);
    });
  });
  
  renderPlantView();
  
  setTimeout(() => {
    btn.classList.remove('spinning');
  }, 1000);
}

function handleExport() {
  const metrics = calculatePlantMetrics();
  const csvContent = `Plant,OEE,Throughput,Defect Rate,Energy\n${state.selectedPlant},${metrics.oee.toFixed(2)},${metrics.throughput.toFixed(0)},${metrics.defectRate.toFixed(2)},${metrics.energy.toFixed(2)}`;
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `plant-${state.selectedPlant}-${Date.now()}.csv`;
  a.click();
}

function backToPlant() {
  state.selectedMachine = null;
  document.getElementById('machineView').classList.add('hidden');
  document.getElementById('plantView').classList.remove('hidden');
  Object.values(machineCharts).forEach(chart => chart.destroy());
  machineCharts = {};
}

// Real-time updates
function startRealTimeUpdates() {
  setInterval(() => {
    updateTimeDisplay();
    
    // Update sensor data
    if (state.selectedMachine) {
      const machine = state.machines[state.selectedPlant].find(m => m.id === state.selectedMachine);
      if (machine) {
        machine.vibration += (Math.random() - 0.5) * 0.5;
        machine.vibration = Math.max(0, Math.min(10, machine.vibration));
        machine.temperature += (Math.random() - 0.5) * 2;
        machine.temperature = Math.max(20, Math.min(80, machine.temperature));
        machine.energy += (Math.random() - 0.5) * 3;
        machine.energy = Math.max(10, Math.min(50, machine.energy));
        
        machine.vibrationHistory.shift();
        machine.vibrationHistory.push(machine.vibration);
        machine.temperatureHistory.shift();
        machine.temperatureHistory.push(machine.temperature);
        machine.energyHistory.shift();
        machine.energyHistory.push(machine.energy);
        
        document.getElementById('vibrationValue').textContent = machine.vibration.toFixed(2) + ' Hz';
        document.getElementById('temperatureValue').textContent = machine.temperature.toFixed(1) + '°C';
        document.getElementById('energySensorValue').textContent = machine.energy.toFixed(1) + ' kW';
        
        if (machineCharts.vibration) {
          machineCharts.vibration.data.datasets[0].data = machine.vibrationHistory;
          machineCharts.vibration.update('none');
        }
        if (machineCharts.temperature) {
          machineCharts.temperature.data.datasets[0].data = machine.temperatureHistory;
          machineCharts.temperature.update('none');
        }
        if (machineCharts.energy) {
          machineCharts.energy.data.datasets[0].data = machine.energyHistory;
          machineCharts.energy.update('none');
        }
      }
    } else {
      // Update plant metrics
      const metrics = calculatePlantMetrics();
      animateValue('throughputValue', metrics.throughput, 0);
      animateValue('energyValue', metrics.energy, 1);
    }
  }, 1000);
}

// Initialize application
function init() {
  initializeMachines();
  generateAlerts();
  updateTimeDisplay();
  updateSystemStatus();
  renderPlantView();
  renderAlerts();
  startRealTimeUpdates();
  
  // Event listeners
  document.getElementById('plantSelector').addEventListener('change', handlePlantChange);
  document.getElementById('refreshBtn').addEventListener('click', handleRefresh);
  document.getElementById('exportBtn').addEventListener('click', handleExport);
  document.getElementById('backToPlant').addEventListener('click', backToPlant);
  
  document.querySelectorAll('.range-btn').forEach(btn => {
    btn.addEventListener('click', handleTimeRangeChange);
  });
}

// Start the application
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}