// Data
const appData = {
    kpis: [
        { name: "Current Foot Traffic", value: 2547, change: 12.5, status: "up", unit: "visitors" },
        { name: "Conversion Rate", value: 18.5, change: -2.3, status: "down", unit: "%" },
        { name: "Avg Dwell Time", value: 23.4, change: 5.2, status: "up", unit: "min" },
        { name: "Estimated Lost Sales", value: 8400, change: -15.3, status: "down", unit: "$" }
    ],
    zones: [
        { id: 1, name: "Entrance", traffic: 450, conversion_rate: 15.2, avg_dwell_time: 5.1, revenue_contribution: 12000 },
        { id: 2, name: "Electronics", traffic: 680, conversion_rate: 22.4, avg_dwell_time: 28.5, revenue_contribution: 45000 },
        { id: 3, name: "Fashion", traffic: 520, conversion_rate: 19.8, avg_dwell_time: 31.2, revenue_contribution: 38000 },
        { id: 4, name: "Food Court", traffic: 420, conversion_rate: 24.5, avg_dwell_time: 45.8, revenue_contribution: 22000 },
        { id: 5, name: "Checkout", traffic: 477, conversion_rate: 18.5, avg_dwell_time: 8.3, revenue_contribution: 0 }
    ],
    hourly_traffic: [
        { hour: "09:00", today: 180, yesterday: 160, last_week: 170 },
        { hour: "10:00", today: 220, yesterday: 200, last_week: 210 },
        { hour: "11:00", today: 310, yesterday: 280, last_week: 290 },
        { hour: "12:00", today: 420, yesterday: 390, last_week: 400 },
        { hour: "13:00", today: 380, yesterday: 350, last_week: 360 },
        { hour: "14:00", today: 290, yesterday: 280, last_week: 275 },
        { hour: "15:00", today: 350, yesterday: 320, last_week: 330 },
        { hour: "16:00", today: 420, yesterday: 410, last_week: 400 }
    ],
    funnel_data: [
        { stage: "Visitors", count: 2547 },
        { stage: "Browsers", count: 2100 },
        { stage: "Converters", count: 450 },
        { stage: "Purchasers", count: 350 }
    ],
    predictions: {
        next_7_days: [420, 450, 480, 510, 490, 520, 540]
    },
    queue_analysis: [
        { checkout: "Checkout 1", queue_length: 8, wait_time: 12 },
        { checkout: "Checkout 2", queue_length: 5, wait_time: 8 },
        { checkout: "Checkout 3", queue_length: 12, wait_time: 18 },
        { checkout: "Self-Checkout", queue_length: 3, wait_time: 4 }
    ],
    customer_segments: [
        { segment: "Power Shoppers", percentage: 18, dwell_time: 45, conversion_rate: 35 },
        { segment: "Browsers", percentage: 45, dwell_time: 20, conversion_rate: 12 },
        { segment: "Casual Visitors", percentage: 25, dwell_time: 15, conversion_rate: 8 },
        { segment: "Repeat Customers", percentage: 12, dwell_time: 38, conversion_rate: 28 }
    ]
};

// Chart instances
let charts = {};

// Initialize dashboard
function initDashboard() {
    renderKPICards();
    setupTabs();
    renderHeatmap();
    renderTrafficChart();
    renderDwellChart();
    renderQueueGrid();
    renderFunnel();
    renderZoneConversionChart();
    renderTopZones();
    renderRevenueChart();
    renderForecastChart();
    renderZoneMetrics();
    renderZoneComparisonChart();
    renderZoneBubbleChart();
    renderSegmentGrid();
    renderSegmentChart();
    updateLastSync();
    
    // Setup zone selector
    document.getElementById('zoneSelect').addEventListener('change', function() {
        renderZoneMetrics();
    });
    
    // Start real-time updates
    setInterval(simulateRealTimeUpdate, 5000);
}

// Render KPI Cards
function renderKPICards() {
    const container = document.getElementById('kpiCards');
    container.innerHTML = appData.kpis.map(kpi => {
        const arrow = kpi.status === 'up' ? '↑' : '↓';
        const valueStr = kpi.unit === '$' ? `$${kpi.value.toLocaleString()}` : 
                        kpi.unit === '%' ? `${kpi.value}%` : 
                        kpi.unit === 'min' ? `${kpi.value} min` : 
                        kpi.value.toLocaleString();
        
        return `
            <div class="kpi-card">
                <div class="kpi-header">
                    <div class="kpi-label">${kpi.name}</div>
                    <div class="kpi-change ${kpi.status}">
                        ${arrow} ${Math.abs(kpi.change)}%
                    </div>
                </div>
                <div class="kpi-value">${valueStr}</div>
            </div>
        `;
    }).join('');
}

// Setup tabs
function setupTabs() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active content
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Render heatmap
function renderHeatmap() {
    const container = document.getElementById('heatmap');
    const maxTraffic = Math.max(...appData.zones.map(z => z.traffic));
    
    container.innerHTML = appData.zones.map(zone => {
        const intensity = zone.traffic / maxTraffic;
        const hue = 220 - (intensity * 220); // Blue to red
        const bgColor = `hsl(${hue}, 70%, 50%)`;
        
        return `
            <div class="heatmap-cell" style="background-color: ${bgColor}; color: white;">
                <div class="heatmap-cell-name">${zone.name}</div>
                <div class="heatmap-cell-value">${zone.traffic}</div>
            </div>
        `;
    }).join('');
}

// Render traffic chart
function renderTrafficChart() {
    const ctx = document.getElementById('trafficChart').getContext('2d');
    
    if (charts.traffic) {
        charts.traffic.destroy();
    }
    
    charts.traffic = new Chart(ctx, {
        type: 'line',
        data: {
            labels: appData.hourly_traffic.map(d => d.hour),
            datasets: [
                {
                    label: 'Today',
                    data: appData.hourly_traffic.map(d => d.today),
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Yesterday',
                    data: appData.hourly_traffic.map(d => d.yesterday),
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Last Week',
                    data: appData.hourly_traffic.map(d => d.last_week),
                    borderColor: '#B4413C',
                    backgroundColor: 'rgba(180, 65, 60, 0.1)',
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render dwell time chart
function renderDwellChart() {
    const ctx = document.getElementById('dwellChart').getContext('2d');
    
    if (charts.dwell) {
        charts.dwell.destroy();
    }
    
    charts.dwell = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: appData.zones.map(z => z.name),
            datasets: [{
                label: 'Avg Dwell Time (min)',
                data: appData.zones.map(z => z.avg_dwell_time),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render queue grid
function renderQueueGrid() {
    const container = document.getElementById('queueGrid');
    container.innerHTML = appData.queue_analysis.map(queue => `
        <div class="queue-item">
            <div class="queue-name">${queue.checkout}</div>
            <div class="queue-length">${queue.queue_length}</div>
            <div class="queue-wait">${queue.wait_time} min wait</div>
        </div>
    `).join('');
}

// Render funnel
function renderFunnel() {
    const container = document.getElementById('funnel');
    const maxCount = appData.funnel_data[0].count;
    
    container.innerHTML = appData.funnel_data.map(stage => {
        const percentage = (stage.count / maxCount) * 100;
        return `
            <div class="funnel-stage">
                <div class="funnel-bar" style="width: ${percentage}%">
                    <span class="funnel-label">${stage.stage}</span>
                    <span class="funnel-value">${stage.count.toLocaleString()}</span>
                </div>
            </div>
        `;
    }).join('');
}

// Render zone conversion chart
function renderZoneConversionChart() {
    const ctx = document.getElementById('zoneConversionChart').getContext('2d');
    
    if (charts.zoneConversion) {
        charts.zoneConversion.destroy();
    }
    
    charts.zoneConversion = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: appData.zones.filter(z => z.id !== 5).map(z => z.name),
            datasets: [{
                label: 'Conversion Rate (%)',
                data: appData.zones.filter(z => z.id !== 5).map(z => z.conversion_rate),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render top zones
function renderTopZones() {
    const container = document.getElementById('topZones');
    const sortedZones = [...appData.zones]
        .filter(z => z.id !== 5)
        .sort((a, b) => b.conversion_rate - a.conversion_rate);
    
    container.innerHTML = sortedZones.map((zone, index) => `
        <div class="metric-item">
            <span class="metric-name">${index + 1}. ${zone.name}</span>
            <span class="metric-value">${zone.conversion_rate}%</span>
        </div>
    `).join('');
}

// Render revenue chart
function renderRevenueChart() {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    if (charts.revenue) {
        charts.revenue.destroy();
    }
    
    charts.revenue = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: appData.zones.filter(z => z.revenue_contribution > 0).map(z => z.name),
            datasets: [{
                data: appData.zones.filter(z => z.revenue_contribution > 0).map(z => z.revenue_contribution),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#e8eaed' }
                }
            }
        }
    });
}

// Render forecast chart
function renderForecastChart() {
    const ctx = document.getElementById('forecastChart').getContext('2d');
    
    if (charts.forecast) {
        charts.forecast.destroy();
    }
    
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    charts.forecast = new Chart(ctx, {
        type: 'line',
        data: {
            labels: days,
            datasets: [{
                label: 'Predicted Peak Traffic',
                data: appData.predictions.next_7_days,
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.2)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render zone metrics
function renderZoneMetrics() {
    const container = document.getElementById('zoneMetrics');
    const zoneId = document.getElementById('zoneSelect').value;
    
    if (zoneId === 'all') {
        container.innerHTML = appData.zones.map(zone => `
            <div class="metric-item">
                <span class="metric-name">${zone.name}</span>
                <span class="metric-value">${zone.traffic} visitors</span>
            </div>
        `).join('');
    } else {
        const zone = appData.zones.find(z => z.id === parseInt(zoneId));
        container.innerHTML = `
            <div class="metric-item">
                <span class="metric-name">Traffic</span>
                <span class="metric-value">${zone.traffic} visitors</span>
            </div>
            <div class="metric-item">
                <span class="metric-name">Conversion Rate</span>
                <span class="metric-value">${zone.conversion_rate}%</span>
            </div>
            <div class="metric-item">
                <span class="metric-name">Avg Dwell Time</span>
                <span class="metric-value">${zone.avg_dwell_time} min</span>
            </div>
            <div class="metric-item">
                <span class="metric-name">Revenue Contribution</span>
                <span class="metric-value">$${zone.revenue_contribution.toLocaleString()}</span>
            </div>
        `;
    }
}

// Render zone comparison chart
function renderZoneComparisonChart() {
    const ctx = document.getElementById('zoneComparisonChart').getContext('2d');
    
    if (charts.zoneComparison) {
        charts.zoneComparison.destroy();
    }
    
    charts.zoneComparison = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Traffic', 'Conversion', 'Dwell Time', 'Revenue'],
            datasets: appData.zones.slice(0, 3).map((zone, index) => ({
                label: zone.name,
                data: [
                    zone.traffic / 10,
                    zone.conversion_rate,
                    zone.avg_dwell_time,
                    zone.revenue_contribution / 1000
                ],
                borderColor: ['#1FB8CD', '#FFC185', '#B4413C'][index],
                backgroundColor: [`rgba(31, 184, 205, 0.2)`, `rgba(255, 193, 133, 0.2)`, `rgba(180, 65, 60, 0.2)`][index]
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                r: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' },
                    pointLabels: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render zone bubble chart
function renderZoneBubbleChart() {
    const ctx = document.getElementById('zoneBubbleChart').getContext('2d');
    
    if (charts.zoneBubble) {
        charts.zoneBubble.destroy();
    }
    
    charts.zoneBubble = new Chart(ctx, {
        type: 'bubble',
        data: {
            datasets: appData.zones.filter(z => z.id !== 5).map((zone, index) => ({
                label: zone.name,
                data: [{
                    x: zone.avg_dwell_time,
                    y: zone.conversion_rate,
                    r: zone.traffic / 30
                }],
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'][index]
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: Dwell ${context.parsed.x}min, Conv ${context.parsed.y}%`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: { display: true, text: 'Avg Dwell Time (min)', color: '#9aa0ac' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    title: { display: true, text: 'Conversion Rate (%)', color: '#9aa0ac' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Render segment grid
function renderSegmentGrid() {
    const container = document.getElementById('segmentGrid');
    container.innerHTML = appData.customer_segments.map(segment => `
        <div class="segment-card">
            <div class="segment-name">${segment.segment}</div>
            <div class="segment-stats">
                <div class="segment-stat">
                    <span class="segment-stat-label">Share</span>
                    <span class="segment-stat-value">${segment.percentage}%</span>
                </div>
                <div class="segment-stat">
                    <span class="segment-stat-label">Dwell Time</span>
                    <span class="segment-stat-value">${segment.dwell_time} min</span>
                </div>
                <div class="segment-stat">
                    <span class="segment-stat-label">Conversion</span>
                    <span class="segment-stat-value">${segment.conversion_rate}%</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Render segment chart
function renderSegmentChart() {
    const ctx = document.getElementById('segmentChart').getContext('2d');
    
    if (charts.segment) {
        charts.segment.destroy();
    }
    
    charts.segment = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: appData.customer_segments.map(s => s.segment),
            datasets: [{
                label: 'Conversion Rate (%)',
                data: appData.customer_segments.map(s => s.conversion_rate),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#e8eaed' }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#9aa0ac' }
                }
            }
        }
    });
}

// Update last sync time
function updateLastSync() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.getElementById('lastSync').textContent = timeStr;
}

// Simulate real-time updates
function simulateRealTimeUpdate() {
    // Update KPI values slightly
    appData.kpis[0].value += Math.floor(Math.random() * 20) - 10;
    appData.kpis[0].value = Math.max(2400, Math.min(2700, appData.kpis[0].value));
    
    // Update zone traffic
    appData.zones.forEach(zone => {
        zone.traffic += Math.floor(Math.random() * 10) - 5;
        zone.traffic = Math.max(300, Math.min(800, zone.traffic));
    });
    
    // Re-render components
    renderKPICards();
    renderHeatmap();
    updateLastSync();
}

// Initialize on load
window.addEventListener('DOMContentLoaded', initDashboard);