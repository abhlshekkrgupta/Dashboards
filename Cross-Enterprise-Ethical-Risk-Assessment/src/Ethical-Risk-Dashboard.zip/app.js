// Dashboard State Management
const DashboardState = {
  currentView: 'executive',
  timeRange: 'day',
  alerts: [],
  complianceData: [],
  incidents: [],
  auditLog: [],
  metrics: {
    complianceScore: 87,
    ethicalRisk: 34,
    operationalCount: 12,
    anomalyCount: 5
  },
  charts: {}
};

// Data Configuration
const CONFIG = {
  departments: ['Finance', 'HR', 'Operations', 'IT', 'Sales'],
  businessUnits: ['Banking', 'Insurance', 'Healthcare', 'Manufacturing', 'Retail', 'Telecom', 'Energy', 'Transport'],
  regulatoryFrameworks: [
    { name: 'RBI', compliance: 92, lastAudit: '2025-11-15', nextAudit: '2025-12-15' },
    { name: 'SEBI', compliance: 88, lastAudit: '2025-11-10', nextAudit: '2025-12-10' },
    { name: 'GDPR', compliance: 95, lastAudit: '2025-11-12', nextAudit: '2025-12-12' },
    { name: 'Data Privacy Act', compliance: 90, lastAudit: '2025-11-08', nextAudit: '2025-12-08' }
  ],
  riskTypes: ['Process Failures', 'Human Errors', 'System Outages', 'Data Breaches', 'Policy Violations'],
  demographicGroups: ['Male/Female', 'Urban/Rural', 'High Income/Low Income', 'Caste-based Representation'],
  alertSeverities: ['Critical', 'High', 'Medium', 'Low']
};

// Initialize Dashboard
function initDashboard() {
  setupEventListeners();
  generateInitialData();
  initializeCharts();
  renderAllViews();
  startRealTimeUpdates();
}

// Event Listeners
function setupEventListeners() {
  // Navigation tabs
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      const view = e.currentTarget.dataset.view;
      switchView(view);
    });
  });

  // Time range selector
  document.getElementById('timeRange').addEventListener('change', (e) => {
    DashboardState.timeRange = e.target.value;
    updateCharts();
  });

  // Audit filters
  const typeFilter = document.getElementById('typeFilter');
  const deptFilter = document.getElementById('departmentFilter');
  
  if (typeFilter) {
    typeFilter.addEventListener('change', renderAuditTrail);
  }
  if (deptFilter) {
    deptFilter.addEventListener('change', renderAuditTrail);
  }

  // Export button
  const exportBtn = document.getElementById('exportBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportReport);
  }

  // Modal close
  const modalClose = document.querySelector('.modal-close');
  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }
}

// View Switching
function switchView(viewName) {
  // Update active tab
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelector(`[data-view="${viewName}"]`).classList.add('active');

  // Update active view
  document.querySelectorAll('.view-container').forEach(view => {
    view.classList.remove('active');
  });
  document.getElementById(`${viewName}View`).classList.add('active');

  DashboardState.currentView = viewName;
}

// Generate Initial Data
function generateInitialData() {
  // Generate alerts
  DashboardState.alerts = generateAlerts(20);
  
  // Generate incidents
  DashboardState.incidents = generateIncidents(30);
  
  // Generate audit log
  DashboardState.auditLog = generateAuditLog(100);
  
  // Generate compliance data
  DashboardState.complianceData = generateComplianceData();
}

// Generate Alerts
function generateAlerts(count) {
  const alerts = [];
  const titles = [
    'Data breach detected in customer database',
    'Compliance violation in financial reporting',
    'AI decision bias threshold exceeded',
    'Unauthorized access attempt',
    'System performance degradation',
    'Policy violation in HR department',
    'Unusual transaction pattern detected',
    'Privacy incident reported',
    'Operational anomaly in manufacturing',
    'Regulatory deadline approaching'
  ];

  for (let i = 0; i < count; i++) {
    const severity = CONFIG.alertSeverities[Math.floor(Math.random() * CONFIG.alertSeverities.length)];
    alerts.push({
      id: i,
      severity: severity,
      title: titles[Math.floor(Math.random() * titles.length)],
      department: CONFIG.departments[Math.floor(Math.random() * CONFIG.departments.length)],
      timestamp: new Date(Date.now() - Math.random() * 86400000).toISOString(),
      status: Math.random() > 0.5 ? 'Open' : 'Resolved'
    });
  }

  return alerts.sort((a, b) => {
    const severityOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });
}

// Generate Incidents
function generateIncidents(count) {
  const incidents = [];
  const issues = [
    'Loan approval bias detected for rural applicants',
    'Personal data exposed in system logs',
    'Discriminatory hiring pattern identified',
    'Unauthorized data access by employee',
    'System outage affecting customer service',
    'Incorrect financial calculation in reports',
    'Policy violation in expense claims',
    'Failed backup procedure',
    'Security vulnerability in API',
    'Incomplete audit documentation'
  ];

  for (let i = 0; i < count; i++) {
    incidents.push({
      id: i,
      issue: issues[Math.floor(Math.random() * issues.length)],
      department: CONFIG.departments[Math.floor(Math.random() * CONFIG.departments.length)],
      severity: CONFIG.alertSeverities[Math.floor(Math.random() * CONFIG.alertSeverities.length)],
      timestamp: new Date(Date.now() - Math.random() * 604800000).toISOString(),
      status: Math.random() > 0.3 ? 'Investigating' : 'Resolved'
    });
  }

  return incidents;
}

// Generate Audit Log
function generateAuditLog(count) {
  const log = [];
  const actions = [
    'AI loan decision approved',
    'Manual override of credit score',
    'Policy update implemented',
    'User access granted',
    'Data export executed',
    'Compliance check completed',
    'Risk assessment performed',
    'System configuration changed',
    'Audit report generated',
    'Training model deployed'
  ];

  const types = ['AI', 'Human', 'System'];
  const owners = ['John Doe', 'Jane Smith', 'System Admin', 'AI Engine', 'Compliance Officer', 'Risk Manager'];
  const outcomes = ['Success', 'Failed', 'Pending', 'Approved', 'Rejected'];

  for (let i = 0; i < count; i++) {
    log.push({
      id: i,
      timestamp: new Date(Date.now() - Math.random() * 2592000000).toISOString(),
      action: actions[Math.floor(Math.random() * actions.length)],
      type: types[Math.floor(Math.random() * types.length)],
      department: CONFIG.departments[Math.floor(Math.random() * CONFIG.departments.length)],
      owner: owners[Math.floor(Math.random() * owners.length)],
      status: Math.random() > 0.2 ? 'Completed' : 'In Progress',
      outcome: outcomes[Math.floor(Math.random() * outcomes.length)]
    });
  }

  return log.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// Generate Compliance Data
function generateComplianceData() {
  const data = [];
  CONFIG.departments.forEach(dept => {
    CONFIG.regulatoryFrameworks.forEach(reg => {
      data.push({
        department: dept,
        regulation: reg.name,
        compliance: Math.floor(Math.random() * 20 + 80),
        status: Math.random() > 0.2 ? 'compliant' : 'warning'
      });
    });
  });
  return data;
}

// Initialize Charts
function initializeCharts() {
  // Compliance Timeline Chart
  const timelineCtx = document.getElementById('complianceTimeline');
  if (timelineCtx) {
    const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`);
    const scores = Array.from({ length: 24 }, () => Math.floor(Math.random() * 15 + 80));
    
    DashboardState.charts.timeline = new Chart(timelineCtx, {
      type: 'line',
      data: {
        labels: hours,
        datasets: [{
          label: 'Compliance Score',
          data: scores,
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: false,
            min: 70,
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#9fa8da' }
          },
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#9fa8da' }
          }
        }
      }
    });
  }

  // Risk Distribution Pie Chart
  const distCtx = document.getElementById('riskDistribution');
  if (distCtx) {
    DashboardState.charts.distribution = new Chart(distCtx, {
      type: 'doughnut',
      data: {
        labels: ['AI Decisions', 'Operational Issues', 'Human Errors', 'Compliance Breaches'],
        datasets: [{
          data: [35, 28, 22, 15],
          backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#e8eaf6', padding: 15 }
          }
        }
      }
    });
  }

  // Demographic Chart
  const demoCtx = document.getElementById('demographicChart');
  if (demoCtx) {
    DashboardState.charts.demographic = new Chart(demoCtx, {
      type: 'bar',
      data: {
        labels: CONFIG.demographicGroups,
        datasets: [
          {
            label: 'Favorable Decisions (%)',
            data: [52, 48, 55, 42],
            backgroundColor: '#1FB8CD'
          },
          {
            label: 'Expected Baseline (%)',
            data: [50, 50, 50, 50],
            backgroundColor: '#5D878F'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#e8eaf6' }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#9fa8da' }
          },
          x: {
            grid: { display: false },
            ticks: { color: '#9fa8da' }
          }
        }
      }
    });
  }

  // Forecast Chart
  const forecastCtx = document.getElementById('forecastChart');
  if (forecastCtx) {
    const days = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];
    
    DashboardState.charts.forecast = new Chart(forecastCtx, {
      type: 'line',
      data: {
        labels: days,
        datasets: [
          {
            label: 'Predicted Compliance Score',
            data: [87, 88, 87, 89, 90, 89, 91],
            borderColor: '#1FB8CD',
            backgroundColor: 'rgba(31, 184, 205, 0.1)',
            tension: 0.4
          },
          {
            label: 'Predicted Ethical Risk',
            data: [34, 33, 35, 32, 31, 33, 30],
            borderColor: '#FFC185',
            backgroundColor: 'rgba(255, 193, 133, 0.1)',
            tension: 0.4
          },
          {
            label: 'Predicted Operational Risk',
            data: [42, 40, 43, 41, 39, 40, 38],
            borderColor: '#B4413C',
            backgroundColor: 'rgba(180, 65, 60, 0.1)',
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#e8eaf6' }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#9fa8da' }
          },
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#9fa8da' }
          }
        }
      }
    });
  }
}

// Render All Views
function renderAllViews() {
  updateMetrics();
  updateAlertSummary();
  renderTopAlerts();
  renderRegulatoryTable();
  renderDepartmentHeatmap();
  renderComplianceIncidents();
  renderEthicalMetrics();
  renderPrivacyIncidents();
  renderOperationalMetrics();
  renderBusinessUnitsHeatmap();
  renderOperationalIncidents();
  renderPredictedRisks();
  renderRecommendations();
  renderAuditTrail();
}

// Update Metrics
function updateMetrics() {
  document.getElementById('complianceScore').textContent = DashboardState.metrics.complianceScore;
  document.getElementById('ethicalRisk').textContent = DashboardState.metrics.ethicalRisk;
  document.getElementById('operationalCount').textContent = DashboardState.metrics.operationalCount;
  document.getElementById('anomalyCount').textContent = DashboardState.metrics.anomalyCount;
}

// Update Alert Summary
function updateAlertSummary() {
  const counts = {
    Critical: 0,
    High: 0,
    Medium: 0,
    Low: 0
  };

  DashboardState.alerts.forEach(alert => {
    if (alert.status === 'Open') {
      counts[alert.severity]++;
    }
  });

  document.getElementById('criticalCount').textContent = counts.Critical;
  document.getElementById('highCount').textContent = counts.High;
  document.getElementById('mediumCount').textContent = counts.Medium;
  document.getElementById('lowCount').textContent = counts.Low;
}

// Render Top Alerts
function renderTopAlerts() {
  const container = document.getElementById('topAlerts');
  if (!container) return;

  const topAlerts = DashboardState.alerts.filter(a => a.status === 'Open').slice(0, 3);
  
  container.innerHTML = topAlerts.map(alert => `
    <div class="alert-card ${alert.severity.toLowerCase()}" onclick="showAlertDetails(${alert.id})">
      <div class="alert-content">
        <div class="alert-title">${alert.title}</div>
        <div class="alert-details">${alert.department} • ${formatDateTime(alert.timestamp)}</div>
      </div>
      <div class="alert-severity" style="background: var(--status-${alert.severity.toLowerCase()}); color: white;">
        ${alert.severity}
      </div>
    </div>
  `).join('');
}

// Render Regulatory Table
function renderRegulatoryTable() {
  const tbody = document.getElementById('regulatoryTableBody');
  if (!tbody) return;

  tbody.innerHTML = CONFIG.regulatoryFrameworks.map(reg => {
    const status = reg.compliance >= 90 ? 'compliant' : reg.compliance >= 80 ? 'warning' : 'critical';
    const icon = reg.compliance >= 90 ? '✓' : reg.compliance >= 80 ? '⚠' : '✗';
    
    return `
      <tr>
        <td><strong>${reg.name}</strong></td>
        <td><strong>${reg.compliance}%</strong></td>
        <td><span class="status-badge ${status}">${icon} ${status.toUpperCase()}</span></td>
        <td>${formatDate(reg.lastAudit)}</td>
        <td>${formatDate(reg.nextAudit)}</td>
      </tr>
    `;
  }).join('');
}

// Render Department Heatmap
function renderDepartmentHeatmap() {
  const container = document.getElementById('departmentHeatmap');
  if (!container) return;

  container.innerHTML = CONFIG.departments.map(dept => {
    const avgCompliance = Math.floor(Math.random() * 20 + 75);
    const riskLevel = avgCompliance >= 90 ? 'low' : avgCompliance >= 80 ? 'medium' : avgCompliance >= 70 ? 'high' : 'critical';
    
    return `
      <div class="heatmap-cell risk-${riskLevel}">
        <div class="heatmap-label">${dept}</div>
        <div class="heatmap-value">${avgCompliance}%</div>
      </div>
    `;
  }).join('');
}

// Render Compliance Incidents
function renderComplianceIncidents() {
  const container = document.getElementById('complianceIncidents');
  if (!container) return;

  const incidents = DashboardState.incidents.slice(0, 5);
  
  container.innerHTML = incidents.map(incident => `
    <div class="incident-item" onclick="showIncidentDetails(${incident.id})">
      <div class="incident-time">${formatDateTime(incident.timestamp)}</div>
      <div class="incident-details">
        <div class="incident-title">${incident.issue}</div>
        <div class="incident-meta">${incident.department} • ${incident.status}</div>
      </div>
      <span class="status-badge ${incident.severity.toLowerCase()}">${incident.severity}</span>
    </div>
  `).join('');
}

// Render Ethical Metrics
function renderEthicalMetrics() {
  const biasScore = Math.floor(Math.random() * 20 + 25);
  document.getElementById('biasScore').textContent = biasScore;
  document.getElementById('biasFill').style.width = `${biasScore}%`;
  
  document.getElementById('fairnessIndex').textContent = Math.floor(Math.random() * 15 + 75);
  document.getElementById('transparencyScore').textContent = Math.floor(Math.random() * 15 + 70);
  document.getElementById('privacyScore').textContent = Math.floor(Math.random() * 10 + 85);
  document.getElementById('societalImpact').textContent = Math.floor(Math.random() * 15 + 80);
}

// Render Privacy Incidents
function renderPrivacyIncidents() {
  const container = document.getElementById('privacyIncidentsList');
  if (!container) return;

  const privacyIncidents = [
    { issue: 'Unauthorized PII access logged', severity: 'High', dept: 'IT', time: new Date(Date.now() - 3600000) },
    { issue: 'Data leak in customer export', severity: 'Critical', dept: 'Sales', time: new Date(Date.now() - 7200000) },
    { issue: 'Cookie consent violation', severity: 'Medium', dept: 'Marketing', time: new Date(Date.now() - 10800000) }
  ];

  container.innerHTML = privacyIncidents.map((incident, idx) => `
    <div class="incident-item">
      <div class="incident-time">${formatDateTime(incident.time)}</div>
      <div class="incident-details">
        <div class="incident-title">${incident.issue}</div>
        <div class="incident-meta">${incident.dept}</div>
      </div>
      <span class="status-badge ${incident.severity.toLowerCase()}">${incident.severity}</span>
    </div>
  `).join('');
}

// Render Operational Metrics
function renderOperationalMetrics() {
  const opRiskScore = Math.floor(Math.random() * 20 + 35);
  const opRiskEl = document.getElementById('opRiskScore');
  if (opRiskEl) {
    opRiskEl.textContent = opRiskScore;
  }

  document.getElementById('processFailures').textContent = Math.floor(Math.random() * 5 + 1);
  document.getElementById('humanErrors').textContent = Math.floor(Math.random() * 8 + 3);
  document.getElementById('systemOutages').textContent = Math.floor(Math.random() * 4 + 1);
  document.getElementById('dataBreaches').textContent = Math.floor(Math.random() * 3);
  document.getElementById('policyViolations').textContent = Math.floor(Math.random() * 4 + 1);
}

// Render Business Units Heatmap
function renderBusinessUnitsHeatmap() {
  const container = document.getElementById('businessUnitsGrid');
  if (!container) return;

  container.innerHTML = CONFIG.businessUnits.map(unit => {
    const riskScore = Math.floor(Math.random() * 60 + 20);
    const riskLevel = riskScore < 30 ? 'low' : riskScore < 50 ? 'medium' : riskScore < 70 ? 'high' : 'critical';
    
    return `
      <div class="heatmap-cell risk-${riskLevel}">
        <div class="heatmap-label">${unit}</div>
        <div class="heatmap-value">Risk: ${riskScore}</div>
      </div>
    `;
  }).join('');
}

// Render Operational Incidents
function renderOperationalIncidents() {
  const container = document.getElementById('operationalIncidents');
  if (!container) return;

  const incidents = DashboardState.incidents.slice(5, 10);
  
  container.innerHTML = incidents.map(incident => `
    <div class="incident-item">
      <div class="incident-time">${formatDateTime(incident.timestamp)}</div>
      <div class="incident-details">
        <div class="incident-title">${incident.issue}</div>
        <div class="incident-meta">${incident.department} • ${incident.status}</div>
      </div>
      <span class="status-badge ${incident.severity.toLowerCase()}">${incident.severity}</span>
    </div>
  `).join('');
}

// Render Predicted Risks
function renderPredictedRisks() {
  const container = document.getElementById('predictedRisksList');
  if (!container) return;

  const predictions = [
    { title: 'Increased compliance violations in Q1', likelihood: 'High', impact: 'High', details: 'Based on historical patterns and current trends' },
    { title: 'AI bias in loan approvals', likelihood: 'Medium', impact: 'Critical', details: 'Demographic disparities detected in model outputs' },
    { title: 'System capacity overload', likelihood: 'Medium', impact: 'Medium', details: 'Traffic patterns suggest infrastructure strain' },
    { title: 'Data privacy regulation changes', likelihood: 'Low', impact: 'High', details: 'Upcoming policy updates may require adjustments' }
  ];

  container.innerHTML = predictions.map(pred => `
    <div class="prediction-item">
      <div class="prediction-header">
        <div class="prediction-title">${pred.title}</div>
        <span class="likelihood-badge likelihood-${pred.likelihood.toLowerCase()}">${pred.likelihood}</span>
      </div>
      <div class="prediction-details">${pred.details}</div>
    </div>
  `).join('');
}

// Render Recommendations
function renderRecommendations() {
  const container = document.getElementById('recommendationsList');
  if (!container) return;

  const recommendations = [
    { title: 'Implement additional AI fairness checks', priority: 'High', details: 'Deploy bias detection algorithms on all decision models' },
    { title: 'Conduct compliance training for Finance team', priority: 'Medium', details: 'Address recent policy violations with targeted training' },
    { title: 'Upgrade security monitoring systems', priority: 'High', details: 'Enhance real-time threat detection capabilities' },
    { title: 'Review and update data retention policies', priority: 'Low', details: 'Ensure alignment with latest regulatory requirements' }
  ];

  container.innerHTML = recommendations.map(rec => `
    <div class="recommendation-item">
      <div class="prediction-header">
        <div class="prediction-title">${rec.title}</div>
        <span class="likelihood-badge likelihood-${rec.priority.toLowerCase()}">${rec.priority}</span>
      </div>
      <div class="prediction-details">${rec.details}</div>
    </div>
  `).join('');
}

// Render Audit Trail
function renderAuditTrail() {
  const tbody = document.getElementById('auditTableBody');
  if (!tbody) return;

  const typeFilter = document.getElementById('typeFilter')?.value || 'all';
  const deptFilter = document.getElementById('departmentFilter')?.value || 'all';

  let filteredLog = DashboardState.auditLog;
  
  if (typeFilter !== 'all') {
    filteredLog = filteredLog.filter(entry => entry.type === typeFilter);
  }
  
  if (deptFilter !== 'all') {
    filteredLog = filteredLog.filter(entry => entry.department === deptFilter);
  }

  tbody.innerHTML = filteredLog.slice(0, 50).map(entry => `
    <tr onclick="showAuditDetails(${entry.id})">
      <td>${formatDateTime(entry.timestamp)}</td>
      <td>${entry.action}</td>
      <td><span class="status-badge ${entry.type.toLowerCase()}">${entry.type}</span></td>
      <td>${entry.department}</td>
      <td>${entry.owner}</td>
      <td><span class="status-badge ${entry.status === 'Completed' ? 'compliant' : 'warning'}">${entry.status}</span></td>
      <td>${entry.outcome}</td>
    </tr>
  `).join('');
}

// Real-time Updates
function startRealTimeUpdates() {
  setInterval(() => {
    // Update metrics with small random changes
    DashboardState.metrics.complianceScore = Math.min(100, Math.max(70, DashboardState.metrics.complianceScore + (Math.random() - 0.5) * 2));
    DashboardState.metrics.ethicalRisk = Math.min(100, Math.max(0, DashboardState.metrics.ethicalRisk + (Math.random() - 0.5) * 2));
    DashboardState.metrics.operationalCount = Math.max(0, DashboardState.metrics.operationalCount + Math.floor((Math.random() - 0.7) * 2));
    DashboardState.metrics.anomalyCount = Math.max(0, DashboardState.metrics.anomalyCount + Math.floor((Math.random() - 0.6) * 2));

    updateMetrics();
    
    // Occasionally add new alerts
    if (Math.random() > 0.9) {
      const newAlerts = generateAlerts(1);
      DashboardState.alerts.unshift(newAlerts[0]);
      updateAlertSummary();
      renderTopAlerts();
    }

    // Update charts
    if (DashboardState.charts.timeline && Math.random() > 0.7) {
      const chart = DashboardState.charts.timeline;
      chart.data.datasets[0].data.shift();
      chart.data.datasets[0].data.push(Math.floor(Math.random() * 15 + 80));
      chart.update('none');
    }
  }, 2000);
}

// Modal Functions
function showAlertDetails(alertId) {
  const alert = DashboardState.alerts.find(a => a.id === alertId);
  if (!alert) return;

  const modal = document.getElementById('detailModal');
  const modalBody = document.getElementById('modalBody');
  
  modalBody.innerHTML = `
    <h2>Alert Details</h2>
    <div style="margin-top: 1rem;">
      <p><strong>Title:</strong> ${alert.title}</p>
      <p><strong>Severity:</strong> <span class="status-badge ${alert.severity.toLowerCase()}">${alert.severity}</span></p>
      <p><strong>Department:</strong> ${alert.department}</p>
      <p><strong>Status:</strong> ${alert.status}</p>
      <p><strong>Timestamp:</strong> ${formatDateTime(alert.timestamp)}</p>
      <p><strong>Description:</strong> This alert requires immediate attention and investigation by the ${alert.department} team.</p>
    </div>
  `;
  
  modal.classList.add('active');
}

function showIncidentDetails(incidentId) {
  const incident = DashboardState.incidents.find(i => i.id === incidentId);
  if (!incident) return;

  const modal = document.getElementById('detailModal');
  const modalBody = document.getElementById('modalBody');
  
  modalBody.innerHTML = `
    <h2>Incident Details</h2>
    <div style="margin-top: 1rem;">
      <p><strong>Issue:</strong> ${incident.issue}</p>
      <p><strong>Severity:</strong> <span class="status-badge ${incident.severity.toLowerCase()}">${incident.severity}</span></p>
      <p><strong>Department:</strong> ${incident.department}</p>
      <p><strong>Status:</strong> ${incident.status}</p>
      <p><strong>Timestamp:</strong> ${formatDateTime(incident.timestamp)}</p>
      <p><strong>Impact:</strong> This incident has been flagged for compliance review and corrective action.</p>
    </div>
  `;
  
  modal.classList.add('active');
}

function showAuditDetails(entryId) {
  const entry = DashboardState.auditLog.find(e => e.id === entryId);
  if (!entry) return;

  const modal = document.getElementById('detailModal');
  const modalBody = document.getElementById('modalBody');
  
  modalBody.innerHTML = `
    <h2>Audit Entry Details</h2>
    <div style="margin-top: 1rem;">
      <p><strong>Action:</strong> ${entry.action}</p>
      <p><strong>Type:</strong> <span class="status-badge">${entry.type}</span></p>
      <p><strong>Department:</strong> ${entry.department}</p>
      <p><strong>Owner:</strong> ${entry.owner}</p>
      <p><strong>Status:</strong> ${entry.status}</p>
      <p><strong>Outcome:</strong> ${entry.outcome}</p>
      <p><strong>Timestamp:</strong> ${formatDateTime(entry.timestamp)}</p>
      <p><strong>Details:</strong> Full audit trail and decision rationale available in compliance system.</p>
    </div>
  `;
  
  modal.classList.add('active');
}

function closeModal() {
  document.getElementById('detailModal').classList.remove('active');
}

// Export Report
function exportReport() {
  const report = {
    timestamp: new Date().toISOString(),
    metrics: DashboardState.metrics,
    alertSummary: {
      critical: DashboardState.alerts.filter(a => a.severity === 'Critical' && a.status === 'Open').length,
      high: DashboardState.alerts.filter(a => a.severity === 'High' && a.status === 'Open').length,
      medium: DashboardState.alerts.filter(a => a.severity === 'Medium' && a.status === 'Open').length,
      low: DashboardState.alerts.filter(a => a.severity === 'Low' && a.status === 'Open').length
    },
    compliance: CONFIG.regulatoryFrameworks
  };

  const dataStr = JSON.stringify(report, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `dashboard-report-${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

// Utility Functions
function formatDateTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;
  
  if (diff < 3600000) {
    return `${Math.floor(diff / 60000)} min ago`;
  } else if (diff < 86400000) {
    return `${Math.floor(diff / 3600000)} hours ago`;
  } else {
    return date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
}

function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function updateCharts() {
  // Update charts based on time range selection
  // This is a placeholder for time range filtering logic
  console.log('Updating charts for time range:', DashboardState.timeRange);
}

// Initialize on page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDashboard);
} else {
  initDashboard();
}