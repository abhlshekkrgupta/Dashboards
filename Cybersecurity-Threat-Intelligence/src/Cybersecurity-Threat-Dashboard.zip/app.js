// Mock Data
const mockData = {
  networkTraffic: [
    { id: "NTA-001", timestamp: "2025-11-22 18:25:43", source_ip: "203.0.113.45", dest_ip: "203.0.113.200", port: 443, protocol: "HTTPS", severity: "high", threat_type: "Suspicious C2 Communication", action: "Blocked", bytes: "2.3 MB" },
    { id: "NTA-002", timestamp: "2025-11-22 18:24:12", source_ip: "203.0.113.78", dest_ip: "198.51.100.45", port: 8080, protocol: "HTTP", severity: "critical", threat_type: "Data Exfiltration", action: "Isolated", bytes: "15.7 MB" },
    { id: "NTA-003", timestamp: "2025-11-22 18:23:05", source_ip: "203.0.113.123", dest_ip: "203.0.113.150", port: 445, protocol: "SMB", severity: "medium", threat_type: "Lateral Movement Attempt", action: "Monitored", bytes: "450 KB" },
    { id: "NTA-004", timestamp: "2025-11-22 18:21:58", source_ip: "203.0.113.92", dest_ip: "8.8.8.8", port: 53, protocol: "DNS", severity: "high", threat_type: "DNS Tunneling", action: "Blocked", bytes: "1.2 MB" },
    { id: "NTA-005", timestamp: "2025-11-22 18:20:33", source_ip: "203.0.113.167", dest_ip: "203.0.113.210", port: 3389, protocol: "RDP", severity: "critical", threat_type: "Brute Force Attack", action: "Blocked", bytes: "680 KB" },
    { id: "NTA-006", timestamp: "2025-11-22 18:19:45", source_ip: "203.0.113.89", dest_ip: "203.0.113.175", port: 22, protocol: "SSH", severity: "high", threat_type: "SSH Brute Force", action: "Blocked", bytes: "320 KB" },
    { id: "NTA-007", timestamp: "2025-11-22 18:18:22", source_ip: "203.0.113.56", dest_ip: "203.0.113.188", port: 80, protocol: "HTTP", severity: "medium", threat_type: "SQL Injection Attempt", action: "Monitored", bytes: "128 KB" },
    { id: "NTA-008", timestamp: "2025-11-22 18:17:10", source_ip: "203.0.113.134", dest_ip: "203.0.113.220", port: 443, protocol: "HTTPS", severity: "critical", threat_type: "Ransomware C2", action: "Isolated", bytes: "8.4 MB" },
    { id: "NTA-009", timestamp: "2025-11-22 18:16:33", source_ip: "203.0.113.71", dest_ip: "203.0.113.195", port: 1433, protocol: "MSSQL", severity: "high", threat_type: "Database Attack", action: "Blocked", bytes: "2.8 MB" },
    { id: "NTA-010", timestamp: "2025-11-22 18:15:18", source_ip: "203.0.113.102", dest_ip: "203.0.113.230", port: 25, protocol: "SMTP", severity: "medium", threat_type: "Spam Campaign", action: "Monitored", bytes: "890 KB" }
  ],
  loginAnomalies: [
    { id: "LA-001", timestamp: "2025-11-22 18:26:15", user_id: "emp_8451", username: "rajesh.sharma@company.in", location: "Moscow, RU", device: "iPhone 14", risk_score: 95, failed_attempts: 7, action: "Flagged for MFA" },
    { id: "LA-002", timestamp: "2025-11-22 18:25:02", user_id: "emp_5623", username: "priya.desai@company.in", location: "Singapore", device: "MacBook Pro", risk_score: 72, failed_attempts: 3, action: "Investigated" },
    { id: "LA-003", timestamp: "2025-11-22 18:23:47", user_id: "emp_9234", username: "amit.kumar@company.in", location: "Bangalore, IN", device: "Windows 10", risk_score: 45, failed_attempts: 1, action: "Monitored" },
    { id: "LA-004", timestamp: "2025-11-22 18:22:30", user_id: "emp_7812", username: "sneha.patel@company.in", location: "Beijing, CN", device: "Android", risk_score: 88, failed_attempts: 5, action: "Account Locked" },
    { id: "LA-005", timestamp: "2025-11-22 18:21:15", user_id: "emp_4567", username: "vikram.singh@company.in", location: "Mumbai, IN", device: "iPad", risk_score: 38, failed_attempts: 2, action: "Cleared" },
    { id: "LA-006", timestamp: "2025-11-22 18:20:05", user_id: "emp_3421", username: "anjali.rao@company.in", location: "London, UK", device: "Dell Laptop", risk_score: 65, failed_attempts: 4, action: "Under Review" },
    { id: "LA-007", timestamp: "2025-11-22 18:18:50", user_id: "emp_6789", username: "karthik.menon@company.in", location: "Dubai, AE", device: "Samsung Galaxy", risk_score: 52, failed_attempts: 2, action: "Monitored" },
    { id: "LA-008", timestamp: "2025-11-22 18:17:22", user_id: "emp_2134", username: "meera.nair@company.in", location: "New York, US", device: "MacBook Air", risk_score: 41, failed_attempts: 1, action: "Cleared" }
  ],
  endpointAlerts: [
    { id: "EA-001", timestamp: "2025-11-22 18:26:52", device_name: "WORKST-BNG-0847", threat_type: "Ransomware Behavior", severity: "critical", process_name: "explorer.exe", process_hash: "a4d9e8c7f2b1a9d3e5c6b8f0a1d9e2c3", status: "Quarantined" },
    { id: "EA-002", timestamp: "2025-11-22 18:25:18", device_name: "SERV-MUM-0512", threat_type: "Credential Dumping", severity: "high", process_name: "mimikatz.exe", process_hash: "d2e4f6a8b0c1d3e5f7a9b1c3d5e7f9a1", status: "Isolated" },
    { id: "EA-003", timestamp: "2025-11-22 18:24:33", device_name: "WORKST-DEL-1923", threat_type: "Malware Detection", severity: "high", process_name: "powershell.exe", process_hash: "b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5", status: "Removed" },
    { id: "EA-004", timestamp: "2025-11-22 18:23:10", device_name: "SERV-CHE-0234", threat_type: "Privilege Escalation", severity: "critical", process_name: "cmd.exe", process_hash: "c6d8e0f2a4b6c8d0e2f4a6b8c0d2e4f6", status: "Blocked" },
    { id: "EA-005", timestamp: "2025-11-22 18:21:45", device_name: "WORKST-HYD-1456", threat_type: "Suspicious DLL Load", severity: "medium", process_name: "svchost.exe", process_hash: "e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7", status: "Analyzed" },
    { id: "EA-006", timestamp: "2025-11-22 18:20:28", device_name: "SERV-BNG-0789", threat_type: "Crypto Mining", severity: "high", process_name: "xmrig.exe", process_hash: "f8a0b2c4d6e8f0a2b4c6d8e0f2a4b6c8", status: "Terminated" },
    { id: "EA-007", timestamp: "2025-11-22 18:19:12", device_name: "WORKST-PUN-2345", threat_type: "Keylogger Detected", severity: "critical", process_name: "winlogon.exe", process_hash: "a9b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9", status: "Quarantined" },
    { id: "EA-008", timestamp: "2025-11-22 18:18:00", device_name: "SERV-KOL-0456", threat_type: "Rootkit Activity", severity: "critical", process_name: "system32.exe", process_hash: "b0c2d4e6f8a0b2c4d6e8f0a2b4c6d8e0", status: "Isolated" }
  ],
  darkWeb: [
    { id: "DW-001", timestamp: "2025-11-22 12:30:00", source: "marketplace", title: "Leaked Database: Indian Banking Credentials", risk_score: 98, records: 150000, tags: ["banking", "india", "credentials", "financial"] },
    { id: "DW-002", timestamp: "2025-11-21 18:15:00", source: "forum", title: "APT28 Discussing New Zero-Day", risk_score: 95, records: 1, tags: ["apt28", "zero-day", "exploit"] }
  ],
  malware: [
    { id: "MAL-001", hash_md5: "5d41402abc4b2a76b9719d911017c592", hash_sha256: "2c26b46911185131006433f5802a3c5c5c7d6d49c2f21e56a7605db1dd25ae2e", family: "Emotet", classification: "Trojan Banker", detections: 2847, first_seen: "2025-11-15 08:00:00" }
  ],
  iocs: [
    { id: "IOC-001", indicator: "203.0.113.67", type: "IP", threat_actor: "APT28", country: "RU", confidence: 0.95 },
    { id: "IOC-002", indicator: "malicious.example.com", type: "Domain", threat_actor: "Scattered Spider", confidence: 0.88 }
  ],
  feeds: [
    { name: "AlienVault OTX", status: "active", last_updated: "2 min ago", records: 15234 },
    { name: "VirusTotal", status: "active", last_updated: "5 min ago", records: 8921 },
    { name: "IBM X-Force", status: "active", last_updated: "1 min ago", records: 12456 },
    { name: "Dark Web Monitor", status: "active", last_updated: "10 min ago", records: 342 }
  ]
};

// Graph Data
const graphData = {
  nodes: [
    { id: "attacker_1", label: "APT28\n(Fancy Bear)", type: "attacker", x: 150, y: 100 },
    { id: "attacker_2", label: "Scattered\nSpider", type: "attacker", x: 150, y: 400 },
    { id: "malware_1", label: "Emotet", type: "malware", x: 400, y: 150 },
    { id: "malware_2", label: "Cobalt Strike", type: "malware", x: 400, y: 350 },
    { id: "infrastructure_1", label: "C2 Server\n203.0.113.89", type: "infrastructure", x: 650, y: 250 },
    { id: "target_1", label: "Banking\nServer", type: "target", x: 900, y: 150 },
    { id: "target_2", label: "Government\nPortal", type: "target", x: 900, y: 350 }
  ],
  edges: [
    { source: "attacker_1", target: "malware_1", label: "Deploys" },
    { source: "attacker_2", target: "malware_2", label: "Deploys" },
    { source: "malware_1", target: "infrastructure_1", label: "Connects" },
    { source: "malware_2", target: "infrastructure_1", label: "Connects" },
    { source: "infrastructure_1", target: "target_1", label: "Targets" },
    { source: "infrastructure_1", target: "target_2", label: "Targets" }
  ]
};

// Initialize
window.addEventListener('DOMContentLoaded', () => {
  initTabs();
  renderNetworkAlerts();
  renderLoginAlerts();
  renderEndpointAlerts();
  renderAttackGraph();
  renderThreatIntelligence();
  initCharts();
  showToastNotifications();
});

// Tab Navigation
function initTabs() {
  const tabs = document.querySelectorAll('.tab');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.dataset.tab;

      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active'));

      tab.classList.add('active');
      document.getElementById(targetTab).classList.add('active');
    });
  });
}

// Render Network Alerts
function renderNetworkAlerts() {
  const container = document.getElementById('networkAlerts');
  const count = document.getElementById('networkCount');
  count.textContent = mockData.networkTraffic.length;

  container.innerHTML = mockData.networkTraffic.map(alert => `
    <div class="alert-item" onclick="showAlertDetails('network', '${alert.id}')">
      <div class="alert-header">
        <span class="alert-id">${alert.id}</span>
        <span class="severity-badge severity-${alert.severity}">${alert.severity}</span>
      </div>
      <div class="alert-details">
        <div><span class="alert-label">Time:</span> <span class="alert-value">${alert.timestamp}</span></div>
        <div><span class="alert-label">Threat:</span> <span class="alert-value">${alert.threat_type}</span></div>
        <div><span class="alert-label">Source:</span> <span class="alert-value">${alert.source_ip}:${alert.port}</span></div>
        <div><span class="alert-label">Destination:</span> <span class="alert-value">${alert.dest_ip}</span></div>
        <div><span class="alert-label">Action:</span> <span class="alert-value">${alert.action}</span></div>
      </div>
    </div>
  `).join('');
}

// Render Login Alerts
function renderLoginAlerts() {
  const container = document.getElementById('loginAlerts');
  const count = document.getElementById('loginCount');
  count.textContent = mockData.loginAnomalies.length;

  container.innerHTML = mockData.loginAnomalies.map(alert => `
    <div class="alert-item" onclick="showAlertDetails('login', '${alert.id}')">
      <div class="alert-header">
        <span class="alert-id">${alert.id}</span>
        <span class="severity-badge severity-${alert.risk_score > 80 ? 'critical' : alert.risk_score > 60 ? 'high' : 'medium'}">
          Risk: ${alert.risk_score}
        </span>
      </div>
      <div class="alert-details">
        <div><span class="alert-label">Time:</span> <span class="alert-value">${alert.timestamp}</span></div>
        <div><span class="alert-label">User:</span> <span class="alert-value">${alert.username}</span></div>
        <div><span class="alert-label">Location:</span> <span class="alert-value">${alert.location}</span></div>
        <div><span class="alert-label">Device:</span> <span class="alert-value">${alert.device}</span></div>
        <div class="risk-score">
          <span class="alert-label">Risk:</span>
          <div class="risk-bar">
            <div class="risk-fill" style="width: ${alert.risk_score}%"></div>
          </div>
          <span class="risk-value">${alert.risk_score}%</span>
        </div>
      </div>
    </div>
  `).join('');
}

// Render Endpoint Alerts
function renderEndpointAlerts() {
  const container = document.getElementById('endpointAlerts');
  const count = document.getElementById('endpointCount');
  count.textContent = mockData.endpointAlerts.length;

  container.innerHTML = mockData.endpointAlerts.map(alert => `
    <div class="alert-item" onclick="showAlertDetails('endpoint', '${alert.id}')">
      <div class="alert-header">
        <span class="alert-id">${alert.id}</span>
        <span class="severity-badge severity-${alert.severity}">${alert.severity}</span>
      </div>
      <div class="alert-details">
        <div><span class="alert-label">Time:</span> <span class="alert-value">${alert.timestamp}</span></div>
        <div><span class="alert-label">Device:</span> <span class="alert-value">${alert.device_name}</span></div>
        <div><span class="alert-label">Threat:</span> <span class="alert-value">${alert.threat_type}</span></div>
        <div><span class="alert-label">Process:</span> <span class="alert-value">${alert.process_name}</span></div>
        <div><span class="alert-label">Status:</span> <span class="alert-value">${alert.status}</span></div>
      </div>
    </div>
  `).join('');
}

// Render Attack Graph
function renderAttackGraph() {
  const svg = document.getElementById('attackGraph');
  const width = svg.clientWidth;
  const height = svg.clientHeight;

  // Scale positions
  const scaleX = width / 1100;
  const scaleY = height / 500;

  let svgContent = '';

  // Colors
  const colors = {
    attacker: '#ff0055',
    malware: '#ff9500',
    infrastructure: '#777',
    target: '#00f5ff'
  };

  // Draw edges first
  graphData.edges.forEach(edge => {
    const source = graphData.nodes.find(n => n.id === edge.source);
    const target = graphData.nodes.find(n => n.id === edge.target);

    svgContent += `
      <line x1="${source.x * scaleX}" y1="${source.y * scaleY}" 
            x2="${target.x * scaleX}" y2="${target.y * scaleY}" 
            stroke="rgba(0, 245, 255, 0.3)" stroke-width="2" 
            stroke-dasharray="5,5"/>
      <text x="${((source.x + target.x) / 2) * scaleX}" 
            y="${((source.y + target.y) / 2) * scaleY}" 
            fill="#888" font-size="10" text-anchor="middle">${edge.label}</text>
    `;
  });

  // Draw nodes
  graphData.nodes.forEach(node => {
    const x = node.x * scaleX;
    const y = node.y * scaleY;
    const color = colors[node.type];

    svgContent += `
      <g class="graph-node" style="cursor: pointer;" onclick="showNodeDetails('${node.id}')">
        <circle cx="${x}" cy="${y}" r="30" 
                fill="${color}" opacity="0.2" stroke="${color}" stroke-width="2"/>
        <circle cx="${x}" cy="${y}" r="20" 
                fill="${color}" opacity="0.8" stroke="${color}" stroke-width="2"/>
        <text x="${x}" y="${y + 45}" 
              fill="#ccc" font-size="12" text-anchor="middle" 
              font-weight="500">${node.label.replace(/\\n/g, ' ')}</text>
      </g>
    `;
  });

  svg.innerHTML = svgContent;
}

// Render Threat Intelligence
function renderThreatIntelligence() {
  // Dark Web Feed
  const darkWebContainer = document.getElementById('darkWebFeed');
  darkWebContainer.innerHTML = mockData.darkWeb.map(item => `
    <div class="intel-item">
      <div class="intel-title">${item.title}</div>
      <div class="intel-meta">
        <span>🕒 ${item.timestamp}</span>
        <span>⚠️ Risk: ${item.risk_score}</span>
        <span>📊 Records: ${item.records.toLocaleString()}</span>
      </div>
      <div style="margin-top: 8px;">
        ${item.tags.map(tag => `<span class="tag">${tag}</span>`).join(' ')}
      </div>
    </div>
  `).join('');

  // Malware Signatures
  const malwareContainer = document.getElementById('malwareSignatures');
  malwareContainer.innerHTML = mockData.malware.map(item => `
    <div class="intel-item">
      <div class="intel-title">${item.family} - ${item.classification}</div>
      <div class="intel-meta" style="margin-top: 8px; display: block;">
        <div style="margin-bottom: 4px;"><strong>MD5:</strong> ${item.hash_md5}</div>
        <div style="margin-bottom: 4px;"><strong>SHA256:</strong> ${item.hash_sha256}</div>
        <div><strong>Detections:</strong> ${item.detections} | <strong>First Seen:</strong> ${item.first_seen}</div>
      </div>
    </div>
  `).join('');

  // IOCs
  const iocsContainer = document.getElementById('iocsList');
  iocsContainer.innerHTML = mockData.iocs.map(item => `
    <div class="intel-item">
      <div class="intel-title">${item.indicator}</div>
      <div class="intel-meta">
        <span>Type: ${item.type}</span>
        <span>Actor: ${item.threat_actor}</span>
        <span>Confidence: ${(item.confidence * 100).toFixed(0)}%</span>
      </div>
    </div>
  `).join('');

  // External Feeds
  const feedsContainer = document.getElementById('feedStatus');
  feedsContainer.innerHTML = mockData.feeds.map(feed => `
    <div class="intel-item" style="border-left-color: #39ff14;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div class="intel-title">${feed.name}</div>
        <span class="severity-badge severity-low">Active</span>
      </div>
      <div class="intel-meta">
        <span>Updated: ${feed.last_updated}</span>
        <span>Records: ${feed.records.toLocaleString()}</span>
      </div>
    </div>
  `).join('');
}

// Initialize Charts
function initCharts() {
  // Region Chart
  const regionCtx = document.getElementById('regionChart').getContext('2d');
  new Chart(regionCtx, {
    type: 'bar',
    data: {
      labels: ['India', 'USA', 'China', 'Russia', 'UK', 'Singapore'],
      datasets: [{
        label: 'Threat Count',
        data: [145, 92, 78, 65, 52, 41],
        backgroundColor: ['#00f5ff', '#ff9500', '#ff0055', '#39ff14', '#ffea00', '#00f5ff']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#ccc' }
        },
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#ccc' }
        }
      }
    }
  });

  // Device Chart
  const deviceCtx = document.getElementById('deviceChart').getContext('2d');
  new Chart(deviceCtx, {
    type: 'doughnut',
    data: {
      labels: ['Workstations', 'Servers', 'Mobile', 'IoT'],
      datasets: [{
        data: [45, 30, 15, 10],
        backgroundColor: ['#00f5ff', '#ff9500', '#39ff14', '#ff0055']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#ccc', padding: 15 }
        }
      }
    }
  });

  // Attack Pattern Chart
  const patternCtx = document.getElementById('attackPatternChart').getContext('2d');
  new Chart(patternCtx, {
    type: 'bar',
    data: {
      labels: ['Phishing', 'Brute Force', 'Exploit', 'Credential Access', 'Lateral Movement', 'Malware', 'SQL Injection', 'DDoS'],
      datasets: [{
        label: 'Incident Count',
        data: [145, 128, 92, 87, 73, 68, 54, 42],
        backgroundColor: '#00f5ff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: 'y',
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          beginAtZero: true,
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#ccc' }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.1)' },
          ticks: { color: '#ccc' }
        }
      }
    }
  });
}

// Show Alert Details in Modal
function showAlertDetails(type, id) {
  const modal = document.getElementById('detailModal');
  const title = document.getElementById('modalTitle');
  const body = document.getElementById('modalBody');

  let alert;
  if (type === 'network') {
    alert = mockData.networkTraffic.find(a => a.id === id);
    title.textContent = `Network Alert: ${alert.id}`;
    body.innerHTML = `
      <div style="line-height: 2;">
        <p><strong>Timestamp:</strong> ${alert.timestamp}</p>
        <p><strong>Threat Type:</strong> ${alert.threat_type}</p>
        <p><strong>Severity:</strong> <span class="severity-badge severity-${alert.severity}">${alert.severity}</span></p>
        <p><strong>Source IP:</strong> ${alert.source_ip}</p>
        <p><strong>Destination IP:</strong> ${alert.dest_ip}</p>
        <p><strong>Port:</strong> ${alert.port}</p>
        <p><strong>Protocol:</strong> ${alert.protocol}</p>
        <p><strong>Data Volume:</strong> ${alert.bytes}</p>
        <p><strong>Action Taken:</strong> ${alert.action}</p>
        <hr style="border-color: rgba(0, 245, 255, 0.2); margin: 20px 0;">
        <h3 style="color: #00f5ff; margin-bottom: 12px;">Recommended Actions:</h3>
        <ul style="line-height: 1.8;">
          <li>Investigate source IP for other malicious activity</li>
          <li>Check for similar patterns in last 24 hours</li>
          <li>Update firewall rules to block this threat</li>
          <li>Review affected systems for compromise indicators</li>
        </ul>
      </div>
    `;
  } else if (type === 'login') {
    alert = mockData.loginAnomalies.find(a => a.id === id);
    title.textContent = `Login Anomaly: ${alert.id}`;
    body.innerHTML = `
      <div style="line-height: 2;">
        <p><strong>Timestamp:</strong> ${alert.timestamp}</p>
        <p><strong>User:</strong> ${alert.username}</p>
        <p><strong>User ID:</strong> ${alert.user_id}</p>
        <p><strong>Location:</strong> ${alert.location}</p>
        <p><strong>Device:</strong> ${alert.device}</p>
        <p><strong>Risk Score:</strong> ${alert.risk_score}/100</p>
        <p><strong>Failed Attempts:</strong> ${alert.failed_attempts}</p>
        <p><strong>Action:</strong> ${alert.action}</p>
        <hr style="border-color: rgba(0, 245, 255, 0.2); margin: 20px 0;">
        <h3 style="color: #00f5ff; margin-bottom: 12px;">Recommended Actions:</h3>
        <ul style="line-height: 1.8;">
          <li>Require multi-factor authentication</li>
          <li>Contact user to verify login attempt</li>
          <li>Monitor account for suspicious activity</li>
          <li>Review access logs for this user</li>
        </ul>
      </div>
    `;
  } else if (type === 'endpoint') {
    alert = mockData.endpointAlerts.find(a => a.id === id);
    title.textContent = `Endpoint Alert: ${alert.id}`;
    body.innerHTML = `
      <div style="line-height: 2;">
        <p><strong>Timestamp:</strong> ${alert.timestamp}</p>
        <p><strong>Device:</strong> ${alert.device_name}</p>
        <p><strong>Threat Type:</strong> ${alert.threat_type}</p>
        <p><strong>Severity:</strong> <span class="severity-badge severity-${alert.severity}">${alert.severity}</span></p>
        <p><strong>Process:</strong> ${alert.process_name}</p>
        <p><strong>Hash:</strong> <code style="background: rgba(0,0,0,0.3); padding: 4px 8px; border-radius: 4px;">${alert.process_hash}</code></p>
        <p><strong>Status:</strong> ${alert.status}</p>
        <hr style="border-color: rgba(0, 245, 255, 0.2); margin: 20px 0;">
        <h3 style="color: #00f5ff; margin-bottom: 12px;">Recommended Actions:</h3>
        <ul style="line-height: 1.8;">
          <li>Isolate device from network immediately</li>
          <li>Run full system scan with updated signatures</li>
          <li>Check for persistence mechanisms</li>
          <li>Review recent user activity on device</li>
          <li>Submit hash to VirusTotal for analysis</li>
        </ul>
      </div>
    `;
  }

  modal.classList.add('active');
}

// Show Node Details
function showNodeDetails(nodeId) {
  const modal = document.getElementById('detailModal');
  const title = document.getElementById('modalTitle');
  const body = document.getElementById('modalBody');
  
  const node = graphData.nodes.find(n => n.id === nodeId);
  title.textContent = node.label.replace(/\\n/g, ' ');
  
  const details = {
    'attacker_1': {
      type: 'Threat Actor',
      description: 'APT28 (Fancy Bear) - Russian state-sponsored group',
      techniques: ['Spear Phishing', 'Credential Dumping', 'Lateral Movement'],
      targets: 'Government, Military, Defense contractors',
      confidence: '95%',
      first_seen: '2025-10-15',
      last_seen: '2025-11-22'
    },
    'attacker_2': {
      type: 'Threat Actor',
      description: 'Scattered Spider - Cybercrime group targeting financial sector',
      techniques: ['Social Engineering', 'SIM Swapping', 'Ransomware'],
      targets: 'Financial services, Technology companies',
      confidence: '88%',
      first_seen: '2025-09-20',
      last_seen: '2025-11-21'
    },
    'malware_1': {
      type: 'Malware',
      description: 'Emotet - Advanced banking trojan and malware dropper',
      techniques: ['Email Spam', 'Credential Theft', 'Module Download'],
      targets: 'Banking credentials, Email accounts',
      confidence: '98%',
      first_seen: '2025-11-15',
      last_seen: '2025-11-22'
    }
  };
  
  const detail = details[nodeId] || {
    type: node.type,
    description: `Details for ${node.label.replace(/\\n/g, ' ')}`,
    confidence: '85%'
  };
  
  body.innerHTML = `
    <div style="line-height: 2;">
      <p><strong>Type:</strong> ${detail.type}</p>
      <p><strong>Description:</strong> ${detail.description}</p>
      ${detail.techniques ? `<p><strong>MITRE ATT&CK Techniques:</strong><br>${detail.techniques.join(', ')}</p>` : ''}
      ${detail.targets ? `<p><strong>Known Targets:</strong> ${detail.targets}</p>` : ''}
      <p><strong>Confidence Score:</strong> ${detail.confidence}</p>
      ${detail.first_seen ? `<p><strong>First Seen:</strong> ${detail.first_seen}</p>` : ''}
      ${detail.last_seen ? `<p><strong>Last Seen:</strong> ${detail.last_seen}</p>` : ''}
    </div>
  `;
  
  modal.classList.add('active');
}

// Close Modal
function closeModal() {
  document.getElementById('detailModal').classList.remove('active');
}

// Toast Notifications
function showToastNotifications() {
  const toasts = [
    { severity: 'critical', title: 'Critical Alert', message: 'Ransomware behavior detected on WORKST-BNG-0847', delay: 1000 },
    { severity: 'high', title: 'High Risk Login', message: 'Suspicious login from Moscow for user rajesh.sharma', delay: 3000 },
    { severity: 'critical', title: 'Data Exfiltration', message: '15.7 MB transferred to unknown destination', delay: 5000 }
  ];

  toasts.forEach(toast => {
    setTimeout(() => showToast(toast), toast.delay);
  });
}

function showToast(toast) {
  const container = document.getElementById('toastContainer');
  const toastEl = document.createElement('div');
  toastEl.className = `toast ${toast.severity}`;
  toastEl.innerHTML = `
    <div class="toast-header">
      <span class="toast-title">${toast.title}</span>
      <span class="severity-badge severity-${toast.severity}">${toast.severity}</span>
    </div>
    <div class="toast-message">${toast.message}</div>
  `;
  
  container.appendChild(toastEl);
  
  setTimeout(() => {
    toastEl.style.animation = 'toastSlideIn 0.3s ease reverse';
    setTimeout(() => toastEl.remove(), 300);
  }, 5000);
}

// Close modal on outside click
window.addEventListener('click', (e) => {
  const modal = document.getElementById('detailModal');
  if (e.target === modal) {
    closeModal();
  }
});