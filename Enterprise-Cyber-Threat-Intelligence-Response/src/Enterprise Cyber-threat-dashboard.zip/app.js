// Dashboard Data
const dashboardData = {
  threatMetrics: {
    totalThreatsToday: 1247,
    threatsTrend: 8,
    mttdMinutes: 34,
    mttdTarget: 30,
    mttrHours: 2.5,
    mttrTarget: 4,
    activeCritical: 3
  },
  threatSeverity: {
    critical: 15,
    high: 28,
    medium: 42,
    low: 15
  },
  regionalDistribution: [
    { region: 'Mumbai', incidents: 245, sector: 'BFSI' },
    { region: 'Delhi', incidents: 198, sector: 'Government' },
    { region: 'Bangalore', incidents: 167, sector: 'IT/Tech' },
    { region: 'Hyderabad', incidents: 142, sector: 'Telecom' },
    { region: 'Chennai', incidents: 89, sector: 'Healthcare' }
  ],
  sectorDistribution: [
    { name: 'BFSI', percentage: 35, count: 436 },
    { name: 'Government', percentage: 22, count: 274 },
    { name: 'IT & Technology', percentage: 18, count: 224 },
    { name: 'Telecom', percentage: 12, count: 149 },
    { name: 'Healthcare', percentage: 8, count: 100 },
    { name: 'Education', percentage: 5, count: 62 }
  ],
  activeThreats: [
    {
      threatId: 'TID-2025-001847',
      name: 'LockBit Ransomware Campaign',
      type: 'Ransomware',
      severity: 'Critical',
      sector: 'BFSI',
      detectionTime: '12 mins ago',
      action: 'Isolate Endpoint',
      status: 'Investigating'
    },
    {
      threatId: 'TID-2025-001846',
      name: 'Phishing - Spoofed RBI Email',
      type: 'Phishing',
      severity: 'High',
      sector: 'BFSI',
      detectionTime: '25 mins ago',
      action: 'Alert Users',
      status: 'Detected'
    },
    {
      threatId: 'TID-2025-001845',
      name: 'DDoS - Banking Portal Attack',
      type: 'DDoS',
      severity: 'High',
      sector: 'BFSI',
      detectionTime: '38 mins ago',
      action: 'Activate WAF Rules',
      status: 'Contained'
    },
    {
      threatId: 'TID-2025-001844',
      name: 'APT - OT/ICS Reconnaissance',
      type: 'APT',
      severity: 'Critical',
      sector: 'Government',
      detectionTime: '1 hour ago',
      action: 'Escalate to CERT-In',
      status: 'Escalated'
    },
    {
      threatId: 'TID-2025-001843',
      name: 'Credential Abuse - Supply Chain',
      type: 'Credential Abuse',
      severity: 'Medium',
      sector: 'IT/Tech',
      detectionTime: '2 hours ago',
      action: 'Force Password Reset',
      status: 'Resolved'
    }
  ],
  threatTimeline: [
    { time: '00:00', critical: 2, high: 8, medium: 15, low: 12 },
    { time: '02:00', critical: 3, high: 12, medium: 22, low: 18 },
    { time: '04:00', critical: 1, high: 6, medium: 18, low: 14 },
    { time: '06:00', critical: 4, high: 15, medium: 28, low: 21 },
    { time: '08:00', critical: 2, high: 10, medium: 24, low: 16 },
    { time: '10:00', critical: 5, high: 18, medium: 32, low: 25 },
    { time: '12:00', critical: 3, high: 14, medium: 26, low: 19 },
    { time: '14:00', critical: 6, high: 20, medium: 35, low: 28 },
    { time: '16:00', critical: 4, high: 16, medium: 30, low: 23 },
    { time: '18:00', critical: 7, high: 22, medium: 38, low: 30 },
    { time: '20:00', critical: 5, high: 18, medium: 32, low: 25 },
    { time: '22:00', critical: 3, high: 12, medium: 25, low: 20 }
  ],
  attackVectors: [
    { vector: 'Phishing', count: 382 },
    { vector: 'Ransomware', count: 245 },
    { vector: 'DDoS Attacks', count: 187 },
    { vector: 'Credential Abuse', count: 156 },
    { vector: 'Supply Chain', count: 98 },
    { vector: 'Zero-Day Exploits', count: 42 }
  ],
  automatedResponses: [
    { action: 'Auto-isolate 5 compromised endpoints', status: 'In Progress', progress: 50 },
    { action: 'Block 12 malicious IP addresses', status: 'Completed', progress: 100 },
    { action: 'Alert 23 users of phishing campaign', status: 'Queued', progress: 0 }
  ],
  ransomwareGroups: [
    { name: 'LockBit', incidents: 20, status: 'Active' },
    { name: 'Killsec', incidents: 15, status: 'Active' },
    { name: 'RansomHub', incidents: 12, status: 'Monitoring' }
  ],
  dataSources: ['Kafka Streams', 'SIEM Logs', 'EDR/Endpoint', 'Firewall', 'Threat Intel Feeds']
};

let charts = {};
let syncCounter = 2;

// Initialize Dashboard
function initDashboard() {
  updateCurrentTime();
  renderRegionalList();
  renderThreatTable();
  renderAttackVectors();
  renderAutomatedResponses();
  renderRansomwareGroups();
  renderDataSources();
  initCharts();
  startRealTimeUpdates();
}

// Update Current Time
function updateCurrentTime() {
  const now = new Date();
  const options = { 
    weekday: 'short', 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
  };
  document.getElementById('currentTime').textContent = now.toLocaleString('en-IN', options) + ' IST';
}

// Update Last Sync Time
function updateLastSync() {
  syncCounter = (syncCounter % 5) + 1;
  document.getElementById('lastSync').textContent = `Last sync: ${syncCounter} seconds ago`;
}

// Update Threat Status
function updateThreatStatus() {
  const activeCritical = dashboardData.threatMetrics.activeCritical;
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  
  if (activeCritical >= 5) {
    statusIndicator.className = 'status-indicator red';
    statusText.textContent = 'CRITICAL';
    statusIndicator.parentElement.parentElement.style.borderColor = 'var(--severity-critical)';
  } else if (activeCritical >= 2) {
    statusIndicator.className = 'status-indicator';
    statusText.textContent = 'ELEVATED';
    statusIndicator.parentElement.parentElement.style.borderColor = 'var(--status-warning)';
  } else {
    statusIndicator.className = 'status-indicator green';
    statusText.textContent = 'NORMAL';
    statusIndicator.parentElement.parentElement.style.borderColor = 'var(--status-active)';
  }
}

// Render Regional List
function renderRegionalList() {
  const container = document.getElementById('regionalList');
  container.innerHTML = dashboardData.regionalDistribution.map(region => `
    <div class="regional-item">
      <div class="regional-info">
        <h4>${region.region}</h4>
        <div class="regional-sector">${region.sector}</div>
      </div>
      <div class="regional-count">${region.incidents}</div>
    </div>
  `).join('');
}

// Render Threat Table
function renderThreatTable() {
  const tbody = document.getElementById('threatTableBody');
  tbody.innerHTML = dashboardData.activeThreats.map(threat => {
    const severityClass = threat.severity.toLowerCase();
    return `
      <tr onclick="showThreatDetails('${threat.threatId}')">
        <td>
          <div class="threat-name">${threat.name}</div>
          <div class="threat-id">${threat.threatId}</div>
        </td>
        <td>${threat.type}</td>
        <td><span class="badge badge-${severityClass}">${threat.severity}</span></td>
        <td>${threat.sector}</td>
        <td>${threat.detectionTime}</td>
        <td><button class="action-btn" onclick="event.stopPropagation(); executeAction('${threat.action}')">${threat.action}</button></td>
        <td>${threat.status}</td>
      </tr>
    `;
  }).join('');
}

// Render Attack Vectors
function renderAttackVectors() {
  const container = document.getElementById('vectorList');
  const maxCount = Math.max(...dashboardData.attackVectors.map(v => v.count));
  
  container.innerHTML = dashboardData.attackVectors.map(vector => {
    const percentage = (vector.count / maxCount) * 100;
    return `
      <div class="vector-item">
        <div class="vector-label">${vector.vector}</div>
        <div class="vector-bar">
          <div class="vector-fill" style="width: ${percentage}%">${vector.count}</div>
        </div>
      </div>
    `;
  }).join('');
}

// Render Automated Responses
function renderAutomatedResponses() {
  const container = document.getElementById('responseGrid');
  container.innerHTML = dashboardData.automatedResponses.map(response => {
    const statusClass = response.status.toLowerCase().replace(' ', '-');
    return `
      <div class="response-card">
        <div class="response-header">
          <div class="response-action">${response.action}</div>
          <div class="response-status ${statusClass}">${response.status}</div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${response.progress}%"></div>
        </div>
      </div>
    `;
  }).join('');
}

// Render Ransomware Groups
function renderRansomwareGroups() {
  const container = document.getElementById('ransomwareList');
  container.innerHTML = dashboardData.ransomwareGroups.map(group => {
    const statusClass = group.status.toLowerCase();
    return `
      <div class="ransomware-item">
        <div class="ransomware-info">
          <div>
            <div class="ransomware-name">${group.name}</div>
            <div class="ransomware-count">${group.incidents} incidents</div>
          </div>
        </div>
        <div class="status-badge ${statusClass}">${group.status}</div>
      </div>
    `;
  }).join('');
}

// Render Data Sources
function renderDataSources() {
  const container = document.getElementById('dataSources');
  container.innerHTML = dashboardData.dataSources.map(source => 
    `<div class="source-tag">${source}</div>`
  ).join('');
}

// Initialize Charts
function initCharts() {
  initSeverityChart();
  initSectorChart();
  initTimelineChart();
}

// Severity Distribution Chart
function initSeverityChart() {
  const ctx = document.getElementById('severityChart').getContext('2d');
  const data = dashboardData.threatSeverity;
  const total = data.critical + data.high + data.medium + data.low;
  
  charts.severity = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Critical', 'High', 'Medium', 'Low'],
      datasets: [{
        label: 'Percentage',
        data: [data.critical, data.high, data.medium, data.low],
        backgroundColor: [
          'rgba(239, 68, 68, 0.8)',
          'rgba(249, 115, 22, 0.8)',
          'rgba(251, 191, 36, 0.8)',
          'rgba(59, 130, 246, 0.8)'
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(249, 115, 22, 1)',
          'rgba(251, 191, 36, 1)',
          'rgba(59, 130, 246, 1)'
        ],
        borderWidth: 2
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(context) {
              const count = Math.round(total * context.parsed.x / 100);
              return `${context.parsed.x}% (${count} threats)`;
            }
          }
        }
      },
      scales: {
        x: {
          beginAtZero: true,
          max: 50,
          ticks: {
            callback: value => value + '%',
            color: '#9ca3af'
          },
          grid: {
            color: 'rgba(50, 184, 198, 0.1)'
          }
        },
        y: {
          ticks: { color: '#e8edf4' },
          grid: { display: false }
        }
      }
    }
  });
}

// Sector Distribution Chart
function initSectorChart() {
  const ctx = document.getElementById('sectorChart').getContext('2d');
  
  charts.sector = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: dashboardData.sectorDistribution.map(s => s.name),
      datasets: [{
        data: dashboardData.sectorDistribution.map(s => s.percentage),
        backgroundColor: [
          '#1FB8CD',
          '#FFC185',
          '#B4413C',
          '#ECEBD5',
          '#5D878F',
          '#DB4545'
        ],
        borderColor: '#1a1f35',
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            color: '#e8edf4',
            padding: 15,
            font: { size: 12 }
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const sector = dashboardData.sectorDistribution[context.dataIndex];
              return `${sector.name}: ${sector.percentage}% (${sector.count} incidents)`;
            }
          }
        }
      }
    }
  });
}

// Timeline Chart
function initTimelineChart() {
  const ctx = document.getElementById('timelineChart').getContext('2d');
  
  charts.timeline = new Chart(ctx, {
    type: 'line',
    data: {
      labels: dashboardData.threatTimeline.map(t => t.time),
      datasets: [
        {
          label: 'Critical',
          data: dashboardData.threatTimeline.map(t => t.critical),
          borderColor: 'rgba(239, 68, 68, 1)',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        },
        {
          label: 'High',
          data: dashboardData.threatTimeline.map(t => t.high),
          borderColor: 'rgba(249, 115, 22, 1)',
          backgroundColor: 'rgba(249, 115, 22, 0.1)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        },
        {
          label: 'Medium',
          data: dashboardData.threatTimeline.map(t => t.medium),
          borderColor: 'rgba(251, 191, 36, 1)',
          backgroundColor: 'rgba(251, 191, 36, 0.1)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        },
        {
          label: 'Low',
          data: dashboardData.threatTimeline.map(t => t.low),
          borderColor: 'rgba(59, 130, 246, 1)',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      plugins: {
        legend: {
          position: 'top',
          labels: {
            color: '#e8edf4',
            padding: 15,
            font: { size: 12 },
            usePointStyle: true
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        x: {
          ticks: { color: '#9ca3af' },
          grid: { color: 'rgba(50, 184, 198, 0.1)' }
        },
        y: {
          beginAtZero: true,
          ticks: { color: '#9ca3af' },
          grid: { color: 'rgba(50, 184, 198, 0.1)' }
        }
      }
    }
  });
}

// Real-time Updates
function startRealTimeUpdates() {
  // Update time every second
  setInterval(() => {
    updateCurrentTime();
    updateLastSync();
  }, 1000);

  // Simulate real-time data updates every 5 seconds
  setInterval(() => {
    updateDynamicData();
  }, 5000);
}

// Update Dynamic Data
function updateDynamicData() {
  // Randomly update threat count
  const change = Math.floor(Math.random() * 10) - 3;
  dashboardData.threatMetrics.totalThreatsToday += change;
  document.getElementById('totalThreats').textContent = dashboardData.threatMetrics.totalThreatsToday.toLocaleString();
  
  // Randomly update critical incidents
  const criticalChange = Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : -1) : 0;
  dashboardData.threatMetrics.activeCritical = Math.max(0, Math.min(10, dashboardData.threatMetrics.activeCritical + criticalChange));
  
  updateThreatStatus();
  
  // Update automation progress
  dashboardData.automatedResponses.forEach(response => {
    if (response.status === 'In Progress' && response.progress < 100) {
      response.progress = Math.min(100, response.progress + 10);
      if (response.progress === 100) {
        response.status = 'Completed';
      }
    }
  });
  renderAutomatedResponses();
}

// Event Handlers
function showThreatDetails(threatId) {
  const threat = dashboardData.activeThreats.find(t => t.threatId === threatId);
  if (threat) {
    alert(`Threat Details:\n\nID: ${threat.threatId}\nName: ${threat.name}\nType: ${threat.type}\nSeverity: ${threat.severity}\nSector: ${threat.sector}\nStatus: ${threat.status}\n\nRecommended Action: ${threat.action}`);
  }
}

function executeAction(action) {
  alert(`Executing action: ${action}\n\nThis would trigger the automated response playbook in a production environment.`);
}

// Initialize on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDashboard);
} else {
  initDashboard();
}