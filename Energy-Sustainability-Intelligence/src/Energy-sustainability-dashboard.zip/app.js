// Site data
const sites = [
    {
        name: "Manufacturing Plant A",
        type: "Manufacturing",
        location: "Texas",
        basePower: 2400,
        renewable_pct: 15,
        co2_per_unit: 45,
        efficiency_ratio: 2.1
    },
    {
        name: "Solar Farm",
        type: "Renewable Energy",
        location: "Arizona",
        basePower: 3500,
        renewable_pct: 95,
        co2_per_unit: 5,
        efficiency_ratio: 3.8
    },
    {
        name: "Data Center",
        type: "Tech",
        location: "California",
        basePower: 1800,
        renewable_pct: 45,
        co2_per_unit: 25,
        efficiency_ratio: 1.9
    },
    {
        name: "Oil Refinery",
        type: "Oil & Gas",
        location: "Louisiana",
        basePower: 5200,
        renewable_pct: 5,
        co2_per_unit: 120,
        efficiency_ratio: 1.5
    }
];

const alerts = [
    {
        alert_id: 1,
        site: "Manufacturing Plant A",
        type: "Efficiency Drop",
        severity: "high",
        message: "Equipment efficiency dropped 12% below baseline",
        timestamp: "2025-11-22 18:30"
    },
    {
        alert_id: 2,
        site: "Data Center",
        type: "Excess Consumption",
        severity: "medium",
        message: "Power consumption 18% above average for this hour",
        timestamp: "2025-11-22 18:15"
    },
    {
        alert_id: 3,
        site: "Oil Refinery",
        type: "Predictive Maintenance",
        severity: "medium",
        message: "Compressor predicted to need maintenance within 5 days",
        timestamp: "2025-11-22 18:00"
    },
    {
        alert_id: 4,
        site: "Solar Farm",
        type: "Weather Impact",
        severity: "low",
        message: "Cloud coverage reducing output by 22%",
        timestamp: "2025-11-22 17:45"
    }
];

let currentSiteIndex = 'all';
let realtimeChart, energyTrendsChart, emissionsTrendsChart, renewableTrendsChart;
let scenarioChart, siteComparisonChart;
let dateRange = 30;

// Generate historical data
function generateHistoricalData(days) {
    const data = [];
    const now = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        
        let totalEnergy = 0;
        let totalCO2 = 0;
        let avgRenewable = 0;
        
        sites.forEach(site => {
            const variation = 0.8 + Math.random() * 0.4;
            const seasonalFactor = 1 + 0.2 * Math.sin((i / 365) * Math.PI * 2);
            const energy = site.basePower * variation * seasonalFactor;
            totalEnergy += energy;
            totalCO2 += (energy / 1000) * site.co2_per_unit * 0.024;
            avgRenewable += site.renewable_pct;
        });
        
        avgRenewable /= sites.length;
        
        data.push({
            date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            energy: Math.round(totalEnergy),
            co2: Math.round(totalCO2 * 10) / 10,
            renewable: Math.round(avgRenewable)
        });
    }
    
    return data;
}

// Calculate current metrics
function calculateMetrics(siteIndex) {
    let totalEnergy = 0;
    let totalCO2 = 0;
    let avgRenewable = 0;
    let avgEfficiency = 0;
    let count = 0;
    
    if (siteIndex === 'all') {
        sites.forEach(site => {
            const variation = 0.9 + Math.random() * 0.2;
            totalEnergy += site.basePower * variation;
            totalCO2 += (site.basePower * variation / 1000) * site.co2_per_unit * 0.024;
            avgRenewable += site.renewable_pct;
            avgEfficiency += (site.efficiency_ratio / 4) * 100;
            count++;
        });
    } else {
        const site = sites[siteIndex];
        const variation = 0.9 + Math.random() * 0.2;
        totalEnergy = site.basePower * variation;
        totalCO2 = (site.basePower * variation / 1000) * site.co2_per_unit * 0.024;
        avgRenewable = site.renewable_pct;
        avgEfficiency = (site.efficiency_ratio / 4) * 100;
        count = 1;
    }
    
    avgRenewable /= count;
    avgEfficiency /= count;
    
    return {
        energy: Math.round(totalEnergy),
        co2: Math.round(totalCO2 * 10) / 10,
        renewable: Math.round(avgRenewable),
        efficiency: Math.round(avgEfficiency)
    };
}

// Update overview metrics
function updateOverviewMetrics() {
    const metrics = calculateMetrics(currentSiteIndex);
    
    document.getElementById('currentEnergy').textContent = `${metrics.energy.toLocaleString()} kW`;
    document.getElementById('currentCO2').textContent = `${metrics.co2} tons`;
    document.getElementById('renewablePct').textContent = `${metrics.renewable}%`;
    document.getElementById('efficiency').textContent = `${metrics.efficiency}%`;
}

// Initialize real-time chart
function initRealtimeChart() {
    const ctx = document.getElementById('realtimeChart').getContext('2d');
    const labels = [];
    const data = [];
    
    for (let i = 60; i >= 0; i--) {
        labels.push(`${i}s`);
        data.push(0);
    }
    
    realtimeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Energy Usage (kW)',
                data: data,
                borderColor: '#00d084',
                backgroundColor: 'rgba(0, 208, 132, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#ffffff' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4', maxTicksLimit: 10 }
                }
            }
        }
    });
}

// Update real-time chart
function updateRealtimeChart() {
    const metrics = calculateMetrics(currentSiteIndex);
    
    realtimeChart.data.datasets[0].data.shift();
    realtimeChart.data.datasets[0].data.push(metrics.energy);
    realtimeChart.update('none');
}

// Initialize trends charts
function initTrendsCharts() {
    const historicalData = generateHistoricalData(dateRange);
    
    // Energy trends
    const ctx1 = document.getElementById('energyTrendsChart').getContext('2d');
    energyTrendsChart = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: historicalData.map(d => d.date),
            datasets: [{
                label: 'Energy Consumption (kW)',
                data: historicalData.map(d => d.energy),
                borderColor: '#00d084',
                backgroundColor: 'rgba(0, 208, 132, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4', maxTicksLimit: 10 }
                }
            }
        }
    });
    
    // Emissions trends
    const ctx2 = document.getElementById('emissionsTrendsChart').getContext('2d');
    emissionsTrendsChart = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: historicalData.map(d => d.date),
            datasets: [{
                label: 'CO2 Emissions (tons)',
                data: historicalData.map(d => d.co2),
                borderColor: '#ff4757',
                backgroundColor: 'rgba(255, 71, 87, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4', maxTicksLimit: 10 }
                }
            }
        }
    });
    
    // Renewable trends
    const ctx3 = document.getElementById('renewableTrendsChart').getContext('2d');
    renewableTrendsChart = new Chart(ctx3, {
        type: 'line',
        data: {
            labels: historicalData.map(d => d.date),
            datasets: [{
                label: 'Renewable Usage (%)',
                data: historicalData.map(d => d.renewable),
                borderColor: '#0099ff',
                backgroundColor: 'rgba(0, 153, 255, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4', maxTicksLimit: 10 }
                }
            }
        }
    });
}

// Update trends charts with new date range
function updateTrendsCharts(days) {
    const historicalData = generateHistoricalData(days);
    
    energyTrendsChart.data.labels = historicalData.map(d => d.date);
    energyTrendsChart.data.datasets[0].data = historicalData.map(d => d.energy);
    energyTrendsChart.update();
    
    emissionsTrendsChart.data.labels = historicalData.map(d => d.date);
    emissionsTrendsChart.data.datasets[0].data = historicalData.map(d => d.co2);
    emissionsTrendsChart.update();
    
    renewableTrendsChart.data.labels = historicalData.map(d => d.date);
    renewableTrendsChart.data.datasets[0].data = historicalData.map(d => d.renewable);
    renewableTrendsChart.update();
}

// Initialize scenario simulator
function initScenarioSimulator() {
    const ctx = document.getElementById('scenarioChart').getContext('2d');
    
    scenarioChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Current', 'With 50% Solar'],
            datasets: [
                {
                    label: 'Annual Cost ($M)',
                    data: [12.5, 10.5],
                    backgroundColor: '#0099ff',
                    yAxisID: 'y'
                },
                {
                    label: 'CO2 Emissions (k tons)',
                    data: [4.5, 3.375],
                    backgroundColor: '#ff4757',
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: { display: true, text: 'Cost ($M)', color: '#0099ff' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: { display: true, text: 'CO2 (k tons)', color: '#ff4757' },
                    grid: { drawOnChartArea: false },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                }
            }
        }
    });
    
    updateScenarioMetrics(50);
}

// Update scenario metrics
function updateScenarioMetrics(solarPct) {
    const baseCost = 12.5;
    const baseCO2 = 4500;
    const baseSolar = 20;
    
    const costReduction = (solarPct - baseSolar) * 0.07;
    const newCost = baseCost - costReduction;
    const co2Reduction = (solarPct - baseSolar) * 0.025 * baseCO2;
    const newCO2 = baseCO2 - co2Reduction;
    const payback = (costReduction > 0) ? (solarPct - baseSolar) * 0.15 : 0;
    
    document.getElementById('solarSliderValue').textContent = `${solarPct}%`;
    document.getElementById('simCost').textContent = `$${newCost.toFixed(1)}M`;
    document.getElementById('simCostChange').textContent = `-$${Math.abs(costReduction).toFixed(1)}M savings`;
    document.getElementById('simCO2').textContent = `${Math.round(newCO2).toLocaleString()} tons`;
    document.getElementById('simCO2Change').textContent = `-${Math.round(co2Reduction).toLocaleString()} tons reduction`;
    document.getElementById('simPayback').textContent = `${payback.toFixed(1)} yrs`;
    document.getElementById('simRenewable').textContent = `${solarPct}%`;
    document.getElementById('simRenewableChange').textContent = `+${solarPct - baseSolar}% increase`;
    
    scenarioChart.data.datasets[0].data[1] = newCost;
    scenarioChart.data.datasets[1].data[1] = newCO2 / 1000;
    scenarioChart.data.labels[1] = `With ${solarPct}% Solar`;
    scenarioChart.update();
}

// Populate alerts
function populateAlerts() {
    const container = document.getElementById('alertsContainer');
    container.innerHTML = '';
    
    alerts.forEach(alert => {
        const alertCard = document.createElement('div');
        alertCard.className = `alert-card ${alert.severity}`;
        alertCard.innerHTML = `
            <div class="alert-content">
                <h3>${alert.site} - ${alert.type}</h3>
                <p>${alert.message}</p>
                <div class="alert-meta">${alert.timestamp}</div>
            </div>
            <div class="alert-badge ${alert.severity}">${alert.severity.toUpperCase()}</div>
        `;
        container.appendChild(alertCard);
    });
}

// Populate site comparison
function populateSiteComparison() {
    const container = document.getElementById('siteComparisonGrid');
    container.innerHTML = '';
    
    sites.forEach(site => {
        const siteCard = document.createElement('div');
        siteCard.className = 'site-card';
        siteCard.innerHTML = `
            <h3>${site.name}</h3>
            <div class="location">${site.location} • ${site.type}</div>
            <div class="site-metric">
                <span class="site-metric-label">Power Usage</span>
                <span class="site-metric-value">${site.basePower} kW</span>
            </div>
            <div class="site-metric">
                <span class="site-metric-label">Renewable %</span>
                <span class="site-metric-value">${site.renewable_pct}%</span>
            </div>
            <div class="site-metric">
                <span class="site-metric-label">CO2/Unit</span>
                <span class="site-metric-value">${site.co2_per_unit} kg</span>
            </div>
            <div class="site-metric">
                <span class="site-metric-label">Efficiency Ratio</span>
                <span class="site-metric-value">${site.efficiency_ratio}</span>
            </div>
        `;
        container.appendChild(siteCard);
    });
}

// Initialize site comparison chart
function initSiteComparisonChart() {
    const ctx = document.getElementById('siteComparisonChart').getContext('2d');
    
    siteComparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: sites.map(s => s.name),
            datasets: [
                {
                    label: 'Efficiency Ratio',
                    data: sites.map(s => s.efficiency_ratio),
                    backgroundColor: '#00d084'
                },
                {
                    label: 'Renewable % (scaled)',
                    data: sites.map(s => s.renewable_pct / 25),
                    backgroundColor: '#0099ff'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: '#b4b4b4' }
                }
            }
        }
    });
}

// Generate heat map
function generateHeatMap() {
    const container = document.getElementById('heatmapGrid');
    container.innerHTML = '';
    container.style.display = 'grid';
    container.style.gridTemplateColumns = 'repeat(24, 1fr)';
    container.style.gap = '4px';
    container.style.marginTop = '20px';
    
    for (let day = 0; day < 7; day++) {
        for (let hour = 0; hour < 24; hour++) {
            const baseLoad = 8000;
            const hourFactor = (hour >= 8 && hour <= 18) ? 1.3 : 0.7;
            const randomVariation = 0.8 + Math.random() * 0.4;
            const consumption = baseLoad * hourFactor * randomVariation;
            
            let color;
            if (consumption < 2000) color = '#1a472a';
            else if (consumption < 4000) color = '#00a86b';
            else if (consumption < 6000) color = '#ffa500';
            else color = '#ff4757';
            
            const cell = document.createElement('div');
            cell.className = 'heatmap-cell';
            cell.style.backgroundColor = color;
            cell.title = `Day ${day + 1}, Hour ${hour}:00 - ${Math.round(consumption)} kW`;
            container.appendChild(cell);
        }
    }
}

// Tab switching
function initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        });
    });
}

// Date range selector
function initDateRangeSelector() {
    const dateBtns = document.querySelectorAll('.date-btn');
    
    dateBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            dateBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const range = parseInt(btn.dataset.range);
            dateRange = range;
            updateTrendsCharts(range);
        });
    });
}

// Site selector
function initSiteSelector() {
    const selector = document.getElementById('siteSelector');
    
    selector.addEventListener('change', (e) => {
        currentSiteIndex = e.target.value === 'all' ? 'all' : parseInt(e.target.value);
        updateOverviewMetrics();
    });
}

// Solar slider
function initSolarSlider() {
    const slider = document.getElementById('solarSlider');
    
    slider.addEventListener('input', (e) => {
        updateScenarioMetrics(parseInt(e.target.value));
    });
}

// Initialize dashboard
function init() {
    initTabs();
    initSiteSelector();
    updateOverviewMetrics();
    initRealtimeChart();
    initTrendsCharts();
    initDateRangeSelector();
    initScenarioSimulator();
    initSolarSlider();
    populateAlerts();
    populateSiteComparison();
    initSiteComparisonChart();
    generateHeatMap();
    
    // Update real-time data every 5 seconds
    setInterval(() => {
        updateOverviewMetrics();
        updateRealtimeChart();
    }, 5000);
}

// Start when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}