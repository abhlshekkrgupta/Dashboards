// Supply Chain Disruption Monitor - India

// Data
const portsData = [
  { name: "JNPT (Navi Mumbai)", location: "Mumbai, Western Coast", coordinates: [300, 450], cargo_volume: 60.05, container_teus: 4.74, turnaround_time: 1.5, risk_level: "high", congestion: 62 },
  { name: "Mundra Port", location: "Gujarat, Western Coast", coordinates: [180, 350], cargo_volume: 17.6, container_teus: 7.4, turnaround_time: 1.8, risk_level: "medium", congestion: 45 },
  { name: "Chennai Port", location: "Tamil Nadu, Eastern Coast", coordinates: [350, 600], cargo_volume: 46.76, container_teus: 1.035, turnaround_time: 2.1, risk_level: "medium", congestion: 52 },
  { name: "Kandla Port", location: "Gujarat", coordinates: [150, 280], cargo_volume: 137, container_teus: 0.17, turnaround_time: 2.0, risk_level: "low", congestion: 35 },
  { name: "Kolkata Port", location: "West Bengal, Eastern Coast", coordinates: [530, 350], cargo_volume: 92.34, container_teus: 0.107, turnaround_time: 2.5, risk_level: "medium", congestion: 48 }
];

const manufacturingHubs = [
  { name: "Chennai", state: "Tamil Nadu", sector: "Automotive", coordinates: [350, 580], risk_level: "medium" },
  { name: "Pune", state: "Maharashtra", sector: "Automotive", coordinates: [240, 380], risk_level: "medium" },
  { name: "Hyderabad", state: "Telangana", sector: "Pharmaceuticals", coordinates: [380, 450], risk_level: "low" },
  { name: "Surat", state: "Gujarat", sector: "Textiles", coordinates: [210, 330], risk_level: "low" },
  { name: "Ahmedabad", state: "Gujarat", sector: "Pharmaceuticals", coordinates: [220, 300], risk_level: "medium" }
];

const kpiData = {
  supply_chain_health: 76,
  ontime_delivery: 82,
  avg_lead_time: 14.5,
  inventory_turnover: 5.2,
  active_disruptions: 8,
  predicted_disruptions_7d: 12
};

const disruptionsData = [
  { id: "DISP001", region: "Mumbai/JNPT", type: "Port Congestion", severity: "high", description: "JNPT experiencing high congestion due to container buildup", affected_areas: ["JNPT", "Mumbai manufacturing cluster"], duration_days: 3, impact: "15% increase in turnaround time", status: "active", mitigation: ["Divert cargo to Mundra", "Activate backup suppliers in Gujarat"] },
  { id: "DISP002", region: "Tamil Nadu/Chennai", type: "Weather", severity: "medium", description: "Monsoon forecast affecting port operations", affected_areas: ["Chennai Port", "surrounding textile units"], duration_days: 5, impact: "10% reduction in capacity", status: "active", mitigation: ["Accelerate inventory buildup", "Secure alternative routing"] },
  { id: "DISP003", region: "Delhi/NCR", type: "Transportation", severity: "medium", description: "Road congestion on Delhi-Mumbai highway", affected_areas: ["Road transport network", "manufacturing hubs"], duration_days: 2, impact: "20% delay in shipments", status: "active", mitigation: ["Use rail alternative", "Adjust delivery schedules"] },
  { id: "DISP004", region: "Hyderabad", type: "Supplier Issue", severity: "low", description: "Pharmaceutical supplier maintenance window", affected_areas: ["Hyderabad pharma cluster"], duration_days: 1, impact: "5% reduction in supply", status: "resolved", mitigation: ["Activate backup supplier"] },
  { id: "DISP005", region: "Gujarat/Mundra", type: "Labor", severity: "medium", description: "Port worker strike planned", affected_areas: ["Mundra Port"], duration_days: 2, impact: "30% capacity reduction", status: "active", mitigation: ["Negotiate resolution", "Use alternate ports"] },
  { id: "DISP006", region: "Kolkata", type: "Weather", severity: "high", description: "Cyclone warning issued for Bay of Bengal", affected_areas: ["Kolkata Port", "Eastern supply routes"], duration_days: 4, impact: "Port closure likely", status: "active", mitigation: ["Halt shipments", "Secure inventory"] },
  { id: "DISP007", region: "Pune", type: "Supplier Issue", severity: "critical", description: "Major automotive parts supplier fire incident", affected_areas: ["Pune auto sector", "Supply chain"], duration_days: 10, impact: "40% production halt", status: "active", mitigation: ["Emergency sourcing", "Production rescheduling"] },
  { id: "DISP008", region: "Bangalore", type: "Transportation", severity: "low", description: "Highway maintenance causing delays", affected_areas: ["Bangalore-Chennai route"], duration_days: 3, impact: "Minor delays", status: "active", mitigation: ["Use alternative routes"] }
];

const regionalMetrics = [
  { region: "Western", locations: ["Mumbai", "Gujarat", "Surat"], risk_level: "high", health_score: 72, disruption_count: 4 },
  { region: "Eastern", locations: ["Kolkata", "Chennai", "West Bengal"], risk_level: "medium", health_score: 78, disruption_count: 2 },
  { region: "Southern", locations: ["Hyderabad", "Bangalore", "Tiruppur"], risk_level: "low", health_score: 84, disruption_count: 1 },
  { region: "Northern", locations: ["Delhi", "Gurugram", "Ludhiana"], risk_level: "medium", health_score: 75, disruption_count: 3 }
];

// State
let currentFilters = {
  region: 'all',
  risk: 'all',
  severity: 'all'
};

let selectedRegion = null;
let charts = {};

// Initialize
function init() {
  updateTimestamp();
  setInterval(updateTimestamp, 1000);
  
  renderKPIs();
  renderMap();
  renderTimeline();
  renderAlerts();
  renderNetwork();
  renderPredictions();
  
  setupEventListeners();
  
  // Simulate real-time updates
  setInterval(simulateDataUpdate, 5000);
}

function updateTimestamp() {
  const now = new Date();
  const options = { 
    weekday: 'short', 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
  };
  document.getElementById('timestamp').textContent = now.toLocaleString('en-IN', options) + ' IST';
}

function renderKPIs() {
  document.getElementById('kpi-health').textContent = kpiData.supply_chain_health + '%';
  document.getElementById('kpi-delivery').textContent = kpiData.ontime_delivery + '%';
  document.getElementById('kpi-leadtime').textContent = kpiData.avg_lead_time;
  document.getElementById('kpi-turnover').textContent = kpiData.inventory_turnover;
  document.getElementById('kpi-active').textContent = kpiData.active_disruptions;
  document.getElementById('kpi-predicted').textContent = kpiData.predicted_disruptions_7d;
}

function renderMap() {
  const portMarkersGroup = document.getElementById('portMarkers');
  const hubMarkersGroup = document.getElementById('hubMarkers');
  
  // Render ports
  portsData.forEach(port => {
    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.classList.add('port-marker');
    
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', port.coordinates[0]);
    circle.setAttribute('cy', port.coordinates[1]);
    circle.setAttribute('r', 8);
    circle.setAttribute('fill', getRiskColor(port.risk_level));
    circle.setAttribute('stroke', '#fff');
    circle.setAttribute('stroke-width', 2);
    
    group.appendChild(circle);
    
    group.addEventListener('mouseenter', (e) => showTooltip(e, port, 'port'));
    group.addEventListener('mouseleave', hideTooltip);
    
    portMarkersGroup.appendChild(group);
  });
  
  // Render manufacturing hubs
  manufacturingHubs.forEach(hub => {
    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.classList.add('hub-marker');
    
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', hub.coordinates[0] - 6);
    rect.setAttribute('y', hub.coordinates[1] - 6);
    rect.setAttribute('width', 12);
    rect.setAttribute('height', 12);
    rect.setAttribute('fill', getRiskColor(hub.risk_level));
    rect.setAttribute('stroke', '#fff');
    rect.setAttribute('stroke-width', 2);
    
    group.appendChild(rect);
    
    group.addEventListener('mouseenter', (e) => showTooltip(e, hub, 'hub'));
    group.addEventListener('mouseleave', hideTooltip);
    
    hubMarkersGroup.appendChild(group);
  });
  
  // Add region click handlers
  document.querySelectorAll('.region').forEach(region => {
    region.addEventListener('click', (e) => {
      const regionName = e.target.dataset.region;
      showRegionalDrilldown(regionName);
    });
  });
}

function showTooltip(event, data, type) {
  const tooltip = document.getElementById('mapTooltip');
  const mapContainer = document.getElementById('mapContainer');
  const rect = mapContainer.getBoundingClientRect();
  
  let content = '';
  if (type === 'port') {
    content = `
      <strong>${data.name}</strong><br>
      <small>${data.location}</small><br>
      Cargo: ${data.cargo_volume} MT<br>
      TEUs: ${data.container_teus}M<br>
      Turnaround: ${data.turnaround_time} days<br>
      Congestion: ${data.congestion}%<br>
      Risk: <strong style="color: ${getRiskColor(data.risk_level)}">${data.risk_level.toUpperCase()}</strong>
    `;
  } else {
    content = `
      <strong>${data.name}</strong><br>
      <small>${data.state}</small><br>
      Sector: ${data.sector}<br>
      Risk: <strong style="color: ${getRiskColor(data.risk_level)}">${data.risk_level.toUpperCase()}</strong>
    `;
  }
  
  tooltip.innerHTML = content;
  tooltip.style.left = (event.clientX - rect.left + 10) + 'px';
  tooltip.style.top = (event.clientY - rect.top + 10) + 'px';
  tooltip.classList.add('visible');
}

function hideTooltip() {
  const tooltip = document.getElementById('mapTooltip');
  tooltip.classList.remove('visible');
}

function getRiskColor(level) {
  const colors = {
    low: '#4ade80',
    medium: '#fbbf24',
    high: '#fb923c',
    critical: '#ef4444'
  };
  return colors[level] || '#94a3b8';
}

function renderTimeline() {
  const ctx = document.getElementById('timelineChart').getContext('2d');
  
  // Generate historical and predicted data
  const dates = [];
  const weatherData = [];
  const portData = [];
  const supplierData = [];
  const transportData = [];
  const laborData = [];
  
  // Past 30 days
  for (let i = 30; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    dates.push(date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }));
    
    weatherData.push(Math.floor(Math.random() * 5) + (i < 7 ? 2 : 0));
    portData.push(Math.floor(Math.random() * 4) + (i < 7 ? 1 : 0));
    supplierData.push(Math.floor(Math.random() * 3));
    transportData.push(Math.floor(Math.random() * 4));
    laborData.push(Math.floor(Math.random() * 2));
  }
  
  // Next 7 days (predictions)
  for (let i = 1; i <= 7; i++) {
    const date = new Date();
    date.setDate(date.getDate() + i);
    dates.push(date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }));
    
    weatherData.push(Math.floor(Math.random() * 6) + 1);
    portData.push(Math.floor(Math.random() * 5) + 1);
    supplierData.push(Math.floor(Math.random() * 4));
    transportData.push(Math.floor(Math.random() * 3));
    laborData.push(Math.floor(Math.random() * 3));
  }
  
  charts.timeline = new Chart(ctx, {
    type: 'line',
    data: {
      labels: dates,
      datasets: [
        {
          label: 'Weather Events',
          data: weatherData,
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          tension: 0.3
        },
        {
          label: 'Port Congestion',
          data: portData,
          borderColor: '#f59e0b',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          tension: 0.3
        },
        {
          label: 'Supplier Delays',
          data: supplierData,
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          tension: 0.3
        },
        {
          label: 'Transportation',
          data: transportData,
          borderColor: '#8b5cf6',
          backgroundColor: 'rgba(139, 92, 246, 0.1)',
          tension: 0.3
        },
        {
          label: 'Labor Issues',
          data: laborData,
          borderColor: '#10b981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text'),
            font: { size: 11 }
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
          },
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          }
        },
        x: {
          ticks: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary'),
            maxRotation: 45,
            minRotation: 45
          },
          grid: {
            display: false
          }
        }
      }
    }
  });
}

function renderAlerts() {
  const container = document.getElementById('alertsContainer');
  const activeDisruptions = disruptionsData.filter(d => d.status === 'active');
  
  // Sort by severity
  const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  activeDisruptions.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
  
  container.innerHTML = activeDisruptions.map(alert => `
    <div class="alert-item ${alert.severity}" onclick="showAlertDetails('${alert.id}')">
      <div class="alert-header">
        <div>
          <div class="alert-title">${alert.type} - ${alert.region}</div>
          <div class="alert-meta">
            <span>🆔 ${alert.id}</span>
            <span>⏱️ ${alert.duration_days} days</span>
          </div>
        </div>
        <span class="alert-severity ${alert.severity}">${alert.severity}</span>
      </div>
      <div class="alert-description">${alert.description}</div>
      <div class="alert-description"><strong>Impact:</strong> ${alert.impact}</div>
      <div class="alert-actions">💡 ${alert.mitigation[0]}</div>
    </div>
  `).join('');
  
  document.getElementById('alertCount').textContent = `${activeDisruptions.length} Active`;
}

function showAlertDetails(alertId) {
  const alert = disruptionsData.find(d => d.id === alertId);
  if (!alert) return;
  
  const content = `
    <div class="drilldown-section">
      <h3>${alert.type} - ${alert.region}</h3>
      <p><strong>Severity:</strong> <span class="risk-score ${alert.severity}">${alert.severity.toUpperCase()}</span></p>
      <p><strong>Description:</strong> ${alert.description}</p>
      <p><strong>Impact:</strong> ${alert.impact}</p>
      <p><strong>Duration:</strong> ${alert.duration_days} days</p>
      <p><strong>Status:</strong> ${alert.status}</p>
    </div>
    <div class="drilldown-section">
      <h3>Affected Areas</h3>
      <ul class="drilldown-list">
        ${alert.affected_areas.map(area => `<li>${area}</li>`).join('')}
      </ul>
    </div>
    <div class="drilldown-section">
      <h3>Recommended Mitigation Actions</h3>
      <ul class="drilldown-list">
        ${alert.mitigation.map(action => `<li>${action}</li>`).join('')}
      </ul>
    </div>
  `;
  
  document.getElementById('drilldownContent').innerHTML = content;
  document.querySelector('.drilldown-card').classList.add('active');
}

function renderNetwork() {
  const svg = document.getElementById('networkGraph');
  svg.innerHTML = '';
  
  // Define network connections (hub to port)
  const connections = [
    { from: manufacturingHubs[0], to: portsData[2], risk: 'medium' }, // Chennai to Chennai Port
    { from: manufacturingHubs[1], to: portsData[0], risk: 'high' }, // Pune to JNPT
    { from: manufacturingHubs[2], to: portsData[2], risk: 'low' }, // Hyderabad to Chennai
    { from: manufacturingHubs[3], to: portsData[1], risk: 'low' }, // Surat to Mundra
    { from: manufacturingHubs[4], to: portsData[1], risk: 'medium' }, // Ahmedabad to Mundra
    { from: manufacturingHubs[4], to: portsData[3], risk: 'low' }, // Ahmedabad to Kandla
  ];
  
  // Draw connections
  connections.forEach(conn => {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.classList.add('network-edge', conn.risk);
    line.setAttribute('x1', conn.from.coordinates[0] * 0.875);
    line.setAttribute('y1', conn.from.coordinates[1] * 0.833);
    line.setAttribute('x2', conn.to.coordinates[0] * 0.875);
    line.setAttribute('y2', conn.to.coordinates[1] * 0.833);
    svg.appendChild(line);
  });
  
  // Draw ports
  portsData.forEach(port => {
    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.classList.add('network-node');
    
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', port.coordinates[0] * 0.875);
    circle.setAttribute('cy', port.coordinates[1] * 0.833);
    circle.setAttribute('r', 15);
    circle.setAttribute('fill', getRiskColor(port.risk_level));
    circle.setAttribute('stroke', '#fff');
    circle.setAttribute('stroke-width', 2);
    
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', port.coordinates[0] * 0.875);
    text.setAttribute('y', port.coordinates[1] * 0.833 - 20);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', getComputedStyle(document.documentElement).getPropertyValue('--color-text'));
    text.setAttribute('font-size', '11');
    text.setAttribute('font-weight', '600');
    text.textContent = port.name.split(' ')[0];
    
    group.appendChild(circle);
    group.appendChild(text);
    svg.appendChild(group);
  });
  
  // Draw hubs
  manufacturingHubs.forEach(hub => {
    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.classList.add('network-node');
    
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', hub.coordinates[0] * 0.875 - 12);
    rect.setAttribute('y', hub.coordinates[1] * 0.833 - 12);
    rect.setAttribute('width', 24);
    rect.setAttribute('height', 24);
    rect.setAttribute('fill', getRiskColor(hub.risk_level));
    rect.setAttribute('stroke', '#fff');
    rect.setAttribute('stroke-width', 2);
    rect.setAttribute('rx', 4);
    
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', hub.coordinates[0] * 0.875);
    text.setAttribute('y', hub.coordinates[1] * 0.833 + 25);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', getComputedStyle(document.documentElement).getPropertyValue('--color-text'));
    text.setAttribute('font-size', '10');
    text.setAttribute('font-weight', '500');
    text.textContent = hub.name;
    
    group.appendChild(rect);
    group.appendChild(text);
    svg.appendChild(group);
  });
}

function renderPredictions() {
  const ctx = document.getElementById('predictionChart').getContext('2d');
  
  const days = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];
  const weatherRisk = [35, 38, 42, 45, 40, 38, 35];
  const portRisk = [45, 48, 52, 50, 48, 46, 44];
  const supplierRisk = [28, 25, 22, 25, 30, 28, 26];
  const transportRisk = [32, 29, 25, 28, 32, 35, 30];
  
  charts.prediction = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: days,
      datasets: [
        {
          label: 'Weather Risk',
          data: weatherRisk,
          backgroundColor: 'rgba(59, 130, 246, 0.7)'
        },
        {
          label: 'Port Congestion Risk',
          data: portRisk,
          backgroundColor: 'rgba(245, 158, 11, 0.7)'
        },
        {
          label: 'Supplier Delay Risk',
          data: supplierRisk,
          backgroundColor: 'rgba(239, 68, 68, 0.7)'
        },
        {
          label: 'Transport Disruption Risk',
          data: transportRisk,
          backgroundColor: 'rgba(139, 92, 246, 0.7)'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text'),
            font: { size: 11 }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
          ticks: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary'),
            callback: function(value) {
              return value + '%';
            }
          },
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          }
        },
        x: {
          ticks: {
            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
          },
          grid: {
            display: false
          }
        }
      }
    }
  });
  
  // Render prediction table
  const tableHTML = `
    <table>
      <thead>
        <tr>
          <th>Day</th>
          <th>Weather</th>
          <th>Port Congestion</th>
          <th>Supplier Delay</th>
          <th>Transportation</th>
          <th>Overall Risk</th>
        </tr>
      </thead>
      <tbody>
        ${days.map((day, i) => {
          const overall = Math.round((weatherRisk[i] + portRisk[i] + supplierRisk[i] + transportRisk[i]) / 4);
          const riskClass = overall > 45 ? 'high' : overall > 35 ? 'medium' : 'low';
          return `
            <tr>
              <td><strong>${day}</strong></td>
              <td>${weatherRisk[i]}%</td>
              <td>${portRisk[i]}%</td>
              <td>${supplierRisk[i]}%</td>
              <td>${transportRisk[i]}%</td>
              <td><span class="risk-score ${riskClass}">${overall}%</span></td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  `;
  
  document.getElementById('predictionTable').innerHTML = tableHTML;
}

function showRegionalDrilldown(regionName) {
  const region = regionalMetrics.find(r => r.region === regionName);
  if (!region) return;
  
  const regionalDisruptions = disruptionsData.filter(d => 
    region.locations.some(loc => d.region.includes(loc))
  );
  
  const content = `
    <div class="drilldown-section">
      <h3>${region.region} Region Overview</h3>
      <p><strong>Health Score:</strong> ${region.health_score}%</p>
      <p><strong>Risk Level:</strong> <span class="risk-score ${region.risk_level}">${region.risk_level.toUpperCase()}</span></p>
      <p><strong>Active Disruptions:</strong> ${region.disruption_count}</p>
    </div>
    <div class="drilldown-section">
      <h3>Major Locations</h3>
      <ul class="drilldown-list">
        ${region.locations.map(loc => `<li>${loc}</li>`).join('')}
      </ul>
    </div>
    <div class="drilldown-section">
      <h3>Active Disruptions</h3>
      <ul class="drilldown-list">
        ${regionalDisruptions.length > 0 
          ? regionalDisruptions.map(d => `<li><strong>${d.type}:</strong> ${d.description}</li>`).join('') 
          : '<li>No active disruptions</li>'}
      </ul>
    </div>
    <div class="drilldown-section">
      <h3>Ports in Region</h3>
      <ul class="drilldown-list">
        ${portsData.filter(p => p.location.includes(regionName) || region.locations.some(loc => p.location.includes(loc)))
          .map(p => `<li><strong>${p.name}:</strong> ${p.congestion}% congestion, ${p.turnaround_time}d turnaround</li>`).join('') || '<li>No major ports</li>'}
      </ul>
    </div>
    <div class="drilldown-section">
      <h3>Manufacturing Hubs</h3>
      <ul class="drilldown-list">
        ${manufacturingHubs.filter(h => region.locations.includes(h.name) || region.locations.includes(h.state))
          .map(h => `<li><strong>${h.name}:</strong> ${h.sector} sector</li>`).join('') || '<li>No major hubs</li>'}
      </ul>
    </div>
    <div class="drilldown-section">
      <h3>Recommended Actions</h3>
      <ul class="drilldown-list">
        <li>Monitor ${region.locations[0]} port capacity daily</li>
        <li>Maintain 10-day buffer inventory</li>
        <li>Activate backup suppliers if disruption exceeds 48 hours</li>
        <li>Review transportation routes weekly</li>
      </ul>
    </div>
  `;
  
  document.getElementById('drilldownContent').innerHTML = content;
  document.querySelector('.drilldown-card').classList.add('active');
}

function setupEventListeners() {
  // Filters
  document.getElementById('regionFilter').addEventListener('change', (e) => {
    currentFilters.region = e.target.value;
    applyFilters();
  });
  
  document.getElementById('riskFilter').addEventListener('change', (e) => {
    currentFilters.risk = e.target.value;
    applyFilters();
  });
  
  document.getElementById('severityFilter').addEventListener('change', (e) => {
    currentFilters.severity = e.target.value;
    applyFilters();
  });
  
  // Close drilldown
  document.getElementById('closeDrilldown').addEventListener('click', () => {
    document.querySelector('.drilldown-card').classList.remove('active');
  });
  
  // Chart tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
    });
  });
}

function applyFilters() {
  // Filter alerts based on current filters
  renderAlerts();
}

function simulateDataUpdate() {
  // Simulate minor fluctuations in KPIs
  kpiData.supply_chain_health += (Math.random() - 0.5) * 2;
  kpiData.supply_chain_health = Math.max(50, Math.min(100, kpiData.supply_chain_health));
  
  kpiData.ontime_delivery += (Math.random() - 0.5) * 1.5;
  kpiData.ontime_delivery = Math.max(50, Math.min(100, kpiData.ontime_delivery));
  
  kpiData.avg_lead_time += (Math.random() - 0.5) * 0.5;
  kpiData.avg_lead_time = Math.max(10, Math.min(20, kpiData.avg_lead_time));
  
  renderKPIs();
}

// Start the application
init();